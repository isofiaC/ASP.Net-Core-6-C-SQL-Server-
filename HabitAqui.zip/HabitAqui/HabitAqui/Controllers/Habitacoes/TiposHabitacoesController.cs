﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using HabitAqui.Data;
using HabitAqui.Models.Habitacoes;
using Microsoft.AspNetCore.Authorization;

namespace HabitAqui.Controllers.Habitacoes
{
    public class TiposHabitacoesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public TiposHabitacoesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: TiposHabitacoes
        public async Task<IActionResult> Index()
        {
              return _context.TiposHabitacoes != null ? 
                          View(await _context.TiposHabitacoes.ToListAsync()) :
                          Problem("Entity set 'ApplicationDbContext.TiposHabitacoes'  is null.");
        }

        // GET: TiposHabitacoes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.TiposHabitacoes == null)
            {
                return NotFound();
            }

            var tipoHabitacao = await _context.TiposHabitacoes
                .FirstOrDefaultAsync(m => m.Id == id);
            if (tipoHabitacao == null)
            {
                return NotFound();
            }

            return View(tipoHabitacao);
        }

        // GET: TiposHabitacoes/Create
        [Authorize(Roles = "Admin")]
        public IActionResult Create()
        {
            return View();
        }

        // POST: TiposHabitacoes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Nome,Descricao,Ativo")] TipoHabitacao tipoHabitacao)
        {
            if (ModelState.IsValid)
            {
                _context.Add(tipoHabitacao);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(tipoHabitacao);
        }

        // GET: TiposHabitacoes/Edit/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.TiposHabitacoes == null)
            {
                return NotFound();
            }

            var tipoHabitacao = await _context.TiposHabitacoes.FindAsync(id);
            if (tipoHabitacao == null)
            {
                return NotFound();
            }
            return View(tipoHabitacao);
        }

        // POST: TiposHabitacoes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Nome,Descricao,Ativo")] TipoHabitacao tipoHabitacao)
        {
            if (id != tipoHabitacao.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(tipoHabitacao);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TipoHabitacaoExists(tipoHabitacao.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(tipoHabitacao);
        }

        // GET: TiposHabitacoes/Delete/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.TiposHabitacoes == null)
            {
                return NotFound();
            }

            var tipoHabitacao = await _context.TiposHabitacoes
                .FirstOrDefaultAsync(m => m.Id == id);
            if (tipoHabitacao == null)
            {
                return NotFound();
            }

            return View(tipoHabitacao);
        }

        // POST: TiposHabitacoes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.TiposHabitacoes == null)
            {
                return Problem("Entity set 'ApplicationDbContext.TiposHabitacoes'  is null.");
            }
            var tipoHabitacao = await _context.TiposHabitacoes.FindAsync(id);
            if (tipoHabitacao != null)
            {
                _context.TiposHabitacoes.Remove(tipoHabitacao);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TipoHabitacaoExists(int id)
        {
          return (_context.TiposHabitacoes?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}

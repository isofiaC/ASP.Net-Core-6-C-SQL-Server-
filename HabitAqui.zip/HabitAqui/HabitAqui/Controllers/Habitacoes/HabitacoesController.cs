﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using HabitAqui.Data;
using HabitAqui.Models.Habitacoes;

namespace HabitAqui.Controllers.Habitacoes
{
    public class HabitacoesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HabitacoesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Habitacoes
        public async Task<IActionResult> Index(/*bool? ativo*/)
        {
            //ViewData["ListaTiposHabitacoes"] = new SelectList(_context.TiposHabitacoes
            //    .OrderBy(t => t.Nome).ToList(), "Id", "Nome");
            //ViewData["ListaProprietario"] = new SelectList(_context.Proprietarios
            //    .OrderBy(t => t.ApplicationUser.PrimeiroNome)
            //    .ThenBy(t => t.ApplicationUser.UltimoNome)
            //    .ToList(), "Id", "PrimeiroNome", "UltimoNome");
            //ViewData["ListaMediadores"] = new SelectList(_context.Mediadores
            //    .OrderBy(m => m.Nome).ToList(), "Id", "Nome");

            //if (ativo != null)
            //{
            //    if (ativo == true)
            //        ViewData["Title"] = "Lista de Habitações Ativas";
            //    else
            //        ViewData["Title"] = "Lista de Habitações Inativas";

            //    return View(await _context.Habitacoes
            //        .Include("TipoHabitacao")
            //        .Include("Proprietario)")
            //        .Include("Mediador")
            //        .Where(h => h.Ativo == ativo).OrderBy(h => h.Nome).ToListAsync());
            //}
            //else
            //{
            //    ViewData["Title"] = "Lista de Habitações";
            //    return View(await _context.Habitacoes
            //        .Include("TipoHabitacao")
            //        .Include("Proprietario)")
            //        .Include("Mediador")
            //        .OrderBy(h => h.Nome).ToListAsync());
            //}

            var applicationDbContext = _context.Habitacoes.Include(h => h.Mediador).Include(h => h.Proprietario).Include(h => h.TipoHabitacao);
            return View(await applicationDbContext.ToListAsync());
        }

        //[HttpPost]
        //public IActionResult Index(string? textoAPesquisar, DateTime? dataInicio, DateTime? dataFim, 
        //    int? numMinMesesArrendamento, int tipohabitacaoId, int proprietarioId, int mediadorId)
        //{
        //    ViewData["ListaTiposHabitacoes"] = new SelectList(_context.TiposHabitacoes
        //        .OrderBy(t => t.Nome).ToList(), "Id", "Nome");
        //    ViewData["ListaProprietario"] = new SelectList(_context.Proprietarios
        //        .OrderBy(t => t.ApplicationUser.PrimeiroNome)
        //        .ThenBy(t => t.ApplicationUser.UltimoNome)
        //        .ToList(), "Id", "PrimeiroNome", "UltimoNome");
        //    ViewData["ListaMediadores"] = new SelectList(_context.Mediadores
        //        .OrderBy(t => t.Nome).ToList(), "Id", "Nome");

        //    var resultado = _context.Habitacoes
        //        .Where(h => ((h.Nome.Contains(textoAPesquisar, StringComparison.OrdinalIgnoreCase)
        //                        || h.Localidade.Contains(textoAPesquisar, 
        //                                StringComparison.OrdinalIgnoreCase)
        //                        || h.Pais.Contains(textoAPesquisar, StringComparison.OrdinalIgnoreCase)
        //                        || h.TipoHabitacao.Nome.Contains(textoAPesquisar,
        //                                StringComparison.OrdinalIgnoreCase)
        //                        || h.Proprietario.ApplicationUser.PrimeiroNome.Contains(textoAPesquisar,
        //                                StringComparison.OrdinalIgnoreCase)
        //                        || h.Mediador.Nome.Contains(textoAPesquisar, 
        //                                StringComparison.OrdinalIgnoreCase))
        //                    || string.IsNullOrWhiteSpace(textoAPesquisar))
        //                && (numMinMesesArrendamento <= h.NumMinMesesArrendamento));

        //    return View(resultado);   
        //}

        //[HttpPost]
        //public IActionResult Search(string? textoAPesquisar, DateTime? dataInicio, DateTime? dataFim,
        //    int? numMinMesesArrendamento, int tipohabitacaoId, int proprietarioId, int mediadorId)
        //{
        //    ViewData["ListaTiposHabitacoes"] = new SelectList(_context.TiposHabitacoes
        //        .OrderBy(t => t.Nome).ToList(), "Id", "Nome");
        //    ViewData["ListaProprietario"] = new SelectList(_context.Proprietarios
        //        .OrderBy(t => t.ApplicationUser.PrimeiroNome)
        //        .ThenBy(t => t.ApplicationUser.UltimoNome)
        //        .ToList(), "Id", "PrimeiroNome", "UltimoNome");
        //    ViewData["ListaMediadores"] = new SelectList(_context.Mediadores
        //        .OrderBy(t => t.Nome).ToList(), "Id", "Nome");

        //    var resultado = _context.Habitacoes
        //        .Where(h => ((h.Nome.Contains(textoAPesquisar, StringComparison.OrdinalIgnoreCase)
        //                        || h.Localidade.Contains(textoAPesquisar, StringComparison.OrdinalIgnoreCase)
        //                        || h.Pais.Contains(textoAPesquisar, StringComparison.OrdinalIgnoreCase)
        //                        || h.TipoHabitacao.Nome.Contains(textoAPesquisar,
        //                        StringComparison.OrdinalIgnoreCase)
        //                        || h.Proprietario.ApplicationUser.PrimeiroNome.Contains(textoAPesquisar,
        //                        StringComparison.OrdinalIgnoreCase)
        //                        || h.Mediador.Nome.Contains(textoAPesquisar, StringComparison.OrdinalIgnoreCase))
        //                        || string.IsNullOrWhiteSpace(textoAPesquisar))
        //                && (numMinMesesArrendamento <= h.NumMinMesesArrendamento)
        //        .Join(_context.Arrendamentos
        //            .Where(a => a.DataInicio < dataInicio);




        //}

        // GET: Habitacoes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Habitacoes == null)
            {
                return NotFound();
            }

            var habitacao = await _context.Habitacoes
                .Include(h => h.Mediador)
                .Include(h => h.Proprietario)
                .Include(h => h.TipoHabitacao)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (habitacao == null)
            {
                return NotFound();
            }

            return View(habitacao);
        }

        // GET: Habitacoes/Create
        public IActionResult Create()
        {
            ViewData["MediadorId"] = new SelectList(_context.Mediadores, "Id", "CodigoPostal");
            ViewData["ProprietarioId"] = new SelectList(_context.Proprietarios, "Id", "ApplicationUserId");
            ViewData["TipoHabitacaoId"] = new SelectList(_context.TiposHabitacoes, "Id", "Nome");
            return View();
        }

        // POST: Habitacoes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Nome,Descricao,Morada,CodigoPostal,Localidade,Pais,RendaMensal,Caucao,Area,NumQuartos,NumWcs,Garagem,NumMinMesesArrendamento,NumMaxMesesArrendamento,AnoConstrucao,EmDestaque,Ativo,TipoHabitacaoId,ProprietarioId,MediadorId")] Habitacao habitacao)
        {
            if (ModelState.IsValid)
            {
                _context.Add(habitacao);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["MediadorId"] = new SelectList(_context.Mediadores, "Id", "CodigoPostal", habitacao.MediadorId);
            ViewData["ProprietarioId"] = new SelectList(_context.Proprietarios, "Id", "ApplicationUserId", habitacao.ProprietarioId);
            ViewData["TipoHabitacaoId"] = new SelectList(_context.TiposHabitacoes, "Id", "Nome", habitacao.TipoHabitacaoId);
            return View(habitacao);
        }

        // GET: Habitacoes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Habitacoes == null)
            {
                return NotFound();
            }

            var habitacao = await _context.Habitacoes.FindAsync(id);
            if (habitacao == null)
            {
                return NotFound();
            }
            ViewData["MediadorId"] = new SelectList(_context.Mediadores, "Id", "CodigoPostal", habitacao.MediadorId);
            ViewData["ProprietarioId"] = new SelectList(_context.Proprietarios, "Id", "ApplicationUserId", habitacao.ProprietarioId);
            ViewData["TipoHabitacaoId"] = new SelectList(_context.TiposHabitacoes, "Id", "Nome", habitacao.TipoHabitacaoId);
            return View(habitacao);
        }

        // POST: Habitacoes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Nome,Descricao,Morada,CodigoPostal,Localidade,Pais,RendaMensal,Caucao,Area,NumQuartos,NumWcs,Garagem,NumMinMesesArrendamento,NumMaxMesesArrendamento,AnoConstrucao,EmDestaque,Ativo,TipoHabitacaoId,ProprietarioId,MediadorId")] Habitacao habitacao)
        {
            if (id != habitacao.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(habitacao);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!HabitacaoExists(habitacao.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["MediadorId"] = new SelectList(_context.Mediadores, "Id", "CodigoPostal", habitacao.MediadorId);
            ViewData["ProprietarioId"] = new SelectList(_context.Proprietarios, "Id", "ApplicationUserId", habitacao.ProprietarioId);
            ViewData["TipoHabitacaoId"] = new SelectList(_context.TiposHabitacoes, "Id", "Nome", habitacao.TipoHabitacaoId);
            return View(habitacao);
        }

        // GET: Habitacoes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Habitacoes == null)
            {
                return NotFound();
            }

            var habitacao = await _context.Habitacoes
                .Include(h => h.Mediador)
                .Include(h => h.Proprietario)
                .Include(h => h.TipoHabitacao)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (habitacao == null)
            {
                return NotFound();
            }

            return View(habitacao);
        }

        // POST: Habitacoes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Habitacoes == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Habitacoes'  is null.");
            }
            var habitacao = await _context.Habitacoes.FindAsync(id);
            if (habitacao != null)
            {
                _context.Habitacoes.Remove(habitacao);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool HabitacaoExists(int id)
        {
            return (_context.Habitacoes?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}

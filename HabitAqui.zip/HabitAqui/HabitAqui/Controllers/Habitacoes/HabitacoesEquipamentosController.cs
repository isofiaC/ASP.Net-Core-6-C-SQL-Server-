﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using HabitAqui.Data;
using HabitAqui.Models.Habitacoes;
using Microsoft.AspNetCore.Authorization;

namespace HabitAqui.Controllers.Habitacoes
{
    public class HabitacoesEquipamentosController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HabitacoesEquipamentosController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: HabitacoesEquipamentos
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.HabitacoesEquipamentos.Include(h => h.Equipamento).Include(h => h.Habitacao);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: HabitacoesEquipamentos/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.HabitacoesEquipamentos == null)
            {
                return NotFound();
            }

            var habitacaoEquipamento = await _context.HabitacoesEquipamentos
                .Include(h => h.Equipamento)
                .Include(h => h.Habitacao)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (habitacaoEquipamento == null)
            {
                return NotFound();
            }

            return View(habitacaoEquipamento);
        }

        // GET: HabitacoesEquipamentos/Create
        [Authorize(Roles = "Administrador, Gestor, Funcionario")]
        public IActionResult Create()
        {
            ViewData["EquipamentoId"] = new SelectList(_context.Equipamentos, "Id", "Designacao");
            ViewData["HabitacaoId"] = new SelectList(_context.Habitacoes, "Id", "CodigoPostal");
            return View();
        }

        // POST: HabitacoesEquipamentos/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Administrador, Gestor, Funcionario")]
        public async Task<IActionResult> Create([Bind("Id,Descricao,Opcional,AluguerMensal,Ativo,HabitacaoId,EquipamentoId")] HabitacaoEquipamento habitacaoEquipamento)
        {
            if (ModelState.IsValid)
            {
                _context.Add(habitacaoEquipamento);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["EquipamentoId"] = new SelectList(_context.Equipamentos, "Id", "Designacao", habitacaoEquipamento.EquipamentoId);
            ViewData["HabitacaoId"] = new SelectList(_context.Habitacoes, "Id", "CodigoPostal", habitacaoEquipamento.HabitacaoId);
            return View(habitacaoEquipamento);
        }

        // GET: HabitacoesEquipamentos/Edit/5
        [Authorize(Roles = "Administrador, Gestor")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.HabitacoesEquipamentos == null)
            {
                return NotFound();
            }

            var habitacaoEquipamento = await _context.HabitacoesEquipamentos.FindAsync(id);
            if (habitacaoEquipamento == null)
            {
                return NotFound();
            }
            ViewData["EquipamentoId"] = new SelectList(_context.Equipamentos, "Id", "Designacao", habitacaoEquipamento.EquipamentoId);
            ViewData["HabitacaoId"] = new SelectList(_context.Habitacoes, "Id", "CodigoPostal", habitacaoEquipamento.HabitacaoId);
            return View(habitacaoEquipamento);
        }

        // POST: HabitacoesEquipamentos/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Administrador, Gestor")]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Descricao,Opcional,AluguerMensal,Ativo,HabitacaoId,EquipamentoId")] HabitacaoEquipamento habitacaoEquipamento)
        {
            if (id != habitacaoEquipamento.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(habitacaoEquipamento);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!HabitacaoEquipamentoExists(habitacaoEquipamento.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["EquipamentoId"] = new SelectList(_context.Equipamentos, "Id", "Designacao", habitacaoEquipamento.EquipamentoId);
            ViewData["HabitacaoId"] = new SelectList(_context.Habitacoes, "Id", "CodigoPostal", habitacaoEquipamento.HabitacaoId);
            return View(habitacaoEquipamento);
        }

        // GET: HabitacoesEquipamentos/Delete/5
        [Authorize(Roles = "Administrador, Gestor")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.HabitacoesEquipamentos == null)
            {
                return NotFound();
            }

            var habitacaoEquipamento = await _context.HabitacoesEquipamentos
                .Include(h => h.Equipamento)
                .Include(h => h.Habitacao)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (habitacaoEquipamento == null)
            {
                return NotFound();
            }

            return View(habitacaoEquipamento);
        }

        // POST: HabitacoesEquipamentos/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Administrador, Gestor")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.HabitacoesEquipamentos == null)
            {
                return Problem("Entity set 'ApplicationDbContext.HabitacoesEquipamentos'  is null.");
            }
            var habitacaoEquipamento = await _context.HabitacoesEquipamentos.FindAsync(id);
            if (habitacaoEquipamento != null)
            {
                _context.HabitacoesEquipamentos.Remove(habitacaoEquipamento);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool HabitacaoEquipamentoExists(int id)
        {
          return (_context.HabitacoesEquipamentos?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}

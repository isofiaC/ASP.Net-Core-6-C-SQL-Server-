﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using HabitAqui.Data;
using HabitAqui.Models.Arrendamentos;
using Microsoft.AspNetCore.Authorization;

namespace HabitAqui.Controllers.Arrendamentos
{
    public class PreReservasController : Controller
    {
        private readonly ApplicationDbContext _context;

        public PreReservasController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: PreReservas
        [Authorize(Roles = "Administrador, Gestor, Funcionario, Arrendatario")]
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.PreReservas.Include(p => p.Arrendatario).Include(p => p.Habitacao);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: PreReservas/Details/5
        [Authorize(Roles = "Administrador, Gestor, Funcionario, Arrendatario")]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.PreReservas == null)
            {
                return NotFound();
            }

            var preReserva = await _context.PreReservas
                .Include(p => p.Arrendatario)
                .Include(p => p.Habitacao)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (preReserva == null)
            {
                return NotFound();
            }

            return View(preReserva);
        }

        // GET: PreReservas/Create
        [Authorize(Roles = "Arrendatario")]
        public IActionResult Create()
        {
            ViewData["ArrendatarioId"] = new SelectList(_context.Arrendatarios, "Id", "ApplicationUserId");
            ViewData["HabitacaoId"] = new SelectList(_context.Habitacoes, "Id", "CodigoPostal");
            return View();
        }

        // POST: PreReservas/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Arrendatario")]
        public async Task<IActionResult> Create([Bind("Id,DataInicio,DataFim,DataHoraPreReserva,Observacoes,HabitacaoId,ArrendatarioId")] PreReserva preReserva)
        {
            if (ModelState.IsValid)
            {
                _context.Add(preReserva);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ArrendatarioId"] = new SelectList(_context.Arrendatarios, "Id", "ApplicationUserId", preReserva.ArrendatarioId);
            ViewData["HabitacaoId"] = new SelectList(_context.Habitacoes, "Id", "CodigoPostal", preReserva.HabitacaoId);
            return View(preReserva);
        }

        // GET: PreReservas/Edit/5
        [Authorize(Roles = "Administrador, Gestor")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.PreReservas == null)
            {
                return NotFound();
            }

            var preReserva = await _context.PreReservas.FindAsync(id);
            if (preReserva == null)
            {
                return NotFound();
            }
            ViewData["ArrendatarioId"] = new SelectList(_context.Arrendatarios, "Id", "ApplicationUserId", preReserva.ArrendatarioId);
            ViewData["HabitacaoId"] = new SelectList(_context.Habitacoes, "Id", "CodigoPostal", preReserva.HabitacaoId);
            return View(preReserva);
        }

        // POST: PreReservas/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Administrador, Gestor")]
        public async Task<IActionResult> Edit(int id, [Bind("Id,DataInicio,DataFim,DataHoraPreReserva,Observacoes,HabitacaoId,ArrendatarioId")] PreReserva preReserva)
        {
            if (id != preReserva.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(preReserva);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PreReservaExists(preReserva.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ArrendatarioId"] = new SelectList(_context.Arrendatarios, "Id", "ApplicationUserId", preReserva.ArrendatarioId);
            ViewData["HabitacaoId"] = new SelectList(_context.Habitacoes, "Id", "CodigoPostal", preReserva.HabitacaoId);
            return View(preReserva);
        }

        // GET: PreReservas/Delete/5
        [Authorize(Roles = "Administrador, Gestor")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.PreReservas == null)
            {
                return NotFound();
            }

            var preReserva = await _context.PreReservas
                .Include(p => p.Arrendatario)
                .Include(p => p.Habitacao)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (preReserva == null)
            {
                return NotFound();
            }

            return View(preReserva);
        }

        // POST: PreReservas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Administrador, Gestor")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.PreReservas == null)
            {
                return Problem("Entity set 'ApplicationDbContext.PreReservas'  is null.");
            }
            var preReserva = await _context.PreReservas.FindAsync(id);
            if (preReserva != null)
            {
                _context.PreReservas.Remove(preReserva);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PreReservaExists(int id)
        {
          return (_context.PreReservas?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}

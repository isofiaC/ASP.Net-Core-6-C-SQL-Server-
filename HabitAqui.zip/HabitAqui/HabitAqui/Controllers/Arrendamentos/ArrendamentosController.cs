﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using HabitAqui.Data;
using HabitAqui.Models.Arrendamentos;
using Microsoft.AspNetCore.Authorization;

namespace HabitAqui.Controllers.Arrendamentos
{
    public class ArrendamentosController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ArrendamentosController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Arrendamentos
        [Authorize(Roles = "Administrador, Gestor, Funcionario")]
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.Arrendamentos.Include(a => a.Arrendatario).Include(a => a.Funcionario).Include(a => a.Habitacao).Include(a => a.PreReserva);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: Arrendamentos/Details/5
        [Authorize(Roles = "Administrador, Gestor, Funcionario")]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Arrendamentos == null)
            {
                return NotFound();
            }

            var arrendamento = await _context.Arrendamentos
                .Include(a => a.Arrendatario)
                .Include(a => a.Funcionario)
                .Include(a => a.Habitacao)
                .Include(a => a.PreReserva)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (arrendamento == null)
            {
                return NotFound();
            }

            return View(arrendamento);
        }

        // GET: Arrendamentos/Create
        [Authorize(Roles = "Administrador, Gestor, Funcionario")]
        public IActionResult Create()
        {
            ViewData["ArrendatarioId"] = new SelectList(_context.Arrendatarios, "Id", "ApplicationUserId");
            ViewData["FuncionarioId"] = new SelectList(_context.Funcionarios, "Id", "ApplicationUserId");
            ViewData["HabitacaoId"] = new SelectList(_context.Habitacoes, "Id", "CodigoPostal");
            ViewData["PreReservaId"] = new SelectList(_context.PreReservas, "Id", "Id");
            return View();
        }

        // POST: Arrendamentos/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Administrador, Gestor, Funcionario")]
        public async Task<IActionResult> Create([Bind("Id,DataInicio,DataFim,RendaMensal,Caucao,DataHoraReserva,ObservacoesReserva,DataHoraCancelamento,ObservacoesCancelamento,DataEntrega,ObservacoesEntrega,DataRececao,ObservacoesRececao,PreReservaId,HabitacaoId,ArrendatarioId,FuncionarioId")] Arrendamento arrendamento)
        {
            if (arrendamento.DataInicio >= arrendamento.DataFim && arrendamento.DataFim.HasValue)
            {
                ModelState.AddModelError("DataInicio", "Data de início tem de ser anterior à data de fim.");
            }

            if (arrendamento.DataEntrega >= arrendamento.DataRececao 
                    && arrendamento.DataEntrega.HasValue && arrendamento.DataRececao.HasValue)
            {
                ModelState.AddModelError("DataEntrega", "Data de entrega tem de ser anterior à data de receção.");
            }

            if (arrendamento.DataHoraReserva >= arrendamento.DataHoraCancelamento 
                    && arrendamento.DataHoraCancelamento.HasValue)
            {
                ModelState.AddModelError("DataHoraReserva", "Data de reserva tem de ser anterior à data de cancelamento.");
            }

            if (ModelState.IsValid)
            {
                _context.Add(arrendamento);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ArrendatarioId"] = new SelectList(_context.Arrendatarios, "Id", "ApplicationUserId", arrendamento.ArrendatarioId);
            ViewData["FuncionarioId"] = new SelectList(_context.Funcionarios, "Id", "ApplicationUserId", arrendamento.FuncionarioId);
            ViewData["HabitacaoId"] = new SelectList(_context.Habitacoes, "Id", "CodigoPostal", arrendamento.HabitacaoId);
            ViewData["PreReservaId"] = new SelectList(_context.PreReservas, "Id", "Id", arrendamento.PreReservaId);
            return View(arrendamento);
        }

        // GET: Arrendamentos/Edit/5
        [Authorize(Roles = "Administrador, Gestor")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Arrendamentos == null)
            {
                return NotFound();
            }

            var arrendamento = await _context.Arrendamentos.FindAsync(id);
            if (arrendamento == null)
            {
                return NotFound();
            }
            ViewData["ArrendatarioId"] = new SelectList(_context.Arrendatarios, "Id", "ApplicationUserId", arrendamento.ArrendatarioId);
            ViewData["FuncionarioId"] = new SelectList(_context.Funcionarios, "Id", "ApplicationUserId", arrendamento.FuncionarioId);
            ViewData["HabitacaoId"] = new SelectList(_context.Habitacoes, "Id", "CodigoPostal", arrendamento.HabitacaoId);
            ViewData["PreReservaId"] = new SelectList(_context.PreReservas, "Id", "Id", arrendamento.PreReservaId);
            return View(arrendamento);
        }

        // POST: Arrendamentos/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Administrador, Gestor")]
        public async Task<IActionResult> Edit(int id, [Bind("Id,DataInicio,DataFim,RendaMensal,Caucao,DataHoraReserva,ObservacoesReserva,DataHoraCancelamento,ObservacoesCancelamento,DataEntrega,ObservacoesEntrega,DataRececao,ObservacoesRececao,PreReservaId,HabitacaoId,ArrendatarioId,FuncionarioId")] Arrendamento arrendamento)
        {
            if (id != arrendamento.Id)
            {
                return NotFound();
            }

            if (arrendamento.DataInicio >= arrendamento.DataFim && arrendamento.DataFim.HasValue)
            {
                ModelState.AddModelError("DataInicio", "Data de início tem de ser anterior à data de fim.");
            }

            if (arrendamento.DataEntrega >= arrendamento.DataRececao
                    && arrendamento.DataEntrega.HasValue && arrendamento.DataRececao.HasValue)
            {
                ModelState.AddModelError("DataEntrega", "Data de entrega tem de ser anterior à data de receção.");
            }

            if (arrendamento.DataHoraReserva >= arrendamento.DataHoraCancelamento
                    && arrendamento.DataHoraCancelamento.HasValue)
            {
                ModelState.AddModelError("DataHoraReserva", "Data de reserva tem de ser anterior à data de cancelamento.");
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(arrendamento);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ArrendamentoExists(arrendamento.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ArrendatarioId"] = new SelectList(_context.Arrendatarios, "Id", "ApplicationUserId", arrendamento.ArrendatarioId);
            ViewData["FuncionarioId"] = new SelectList(_context.Funcionarios, "Id", "ApplicationUserId", arrendamento.FuncionarioId);
            ViewData["HabitacaoId"] = new SelectList(_context.Habitacoes, "Id", "CodigoPostal", arrendamento.HabitacaoId);
            ViewData["PreReservaId"] = new SelectList(_context.PreReservas, "Id", "Id", arrendamento.PreReservaId);
            return View(arrendamento);
        }

        // GET: Arrendamentos/Delete/5
        [Authorize(Roles = "Administrador, Gestor")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Arrendamentos == null)
            {
                return NotFound();
            }

            var arrendamento = await _context.Arrendamentos
                .Include(a => a.Arrendatario)
                .Include(a => a.Funcionario)
                .Include(a => a.Habitacao)
                .Include(a => a.PreReserva)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (arrendamento == null)
            {
                return NotFound();
            }

            return View(arrendamento);
        }

        // POST: Arrendamentos/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Administrador, Gestor")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Arrendamentos == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Arrendamentos'  is null.");
            }
            var arrendamento = await _context.Arrendamentos.FindAsync(id);
            if (arrendamento != null)
            {
                _context.Arrendamentos.Remove(arrendamento);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ArrendamentoExists(int id)
        {
          return (_context.Arrendamentos?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}

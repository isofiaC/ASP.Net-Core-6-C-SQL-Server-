﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using HabitAqui.Data;
using HabitAqui.Models.Arrendamentos;
using Microsoft.AspNetCore.Authorization;

namespace HabitAqui.Controllers.Arrendamentos
{
    public class ArrendamentosHabitacoesServicosOpcionaisController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ArrendamentosHabitacoesServicosOpcionaisController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: ArrendamentosHabitacoesServicosOpcionais
        [Authorize(Roles = "Administrador, Gestor, Funcionario")]
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.ArrendamentosHabitacoesServicosOpcionais.Include(a => a.Arrendamento).Include(a => a.HabitacaoServicoOpcional);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: ArrendamentosHabitacoesServicosOpcionais/Details/5
        [Authorize(Roles = "Administrador, Gestor, Funcionario")]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.ArrendamentosHabitacoesServicosOpcionais == null)
            {
                return NotFound();
            }

            var arrendamentoHabitacaoServicoOpcional = await _context.ArrendamentosHabitacoesServicosOpcionais
                .Include(a => a.Arrendamento)
                .Include(a => a.HabitacaoServicoOpcional)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (arrendamentoHabitacaoServicoOpcional == null)
            {
                return NotFound();
            }

            return View(arrendamentoHabitacaoServicoOpcional);
        }

        // GET: ArrendamentosHabitacoesServicosOpcionais/Create
        [Authorize(Roles = "Administrador, Gestor, Funcionario")]
        public IActionResult Create()
        {
            ViewData["ArrendamentoId"] = new SelectList(_context.Arrendamentos, "Id", "Id");
            ViewData["HabitacaoServicoOpcionalId"] = new SelectList(_context.HabitacoesServicos, "Id", "Descricao");
            return View();
        }

        // POST: ArrendamentosHabitacoesServicosOpcionais/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Administrador, Gestor, Funcionario")]
        public async Task<IActionResult> Create([Bind("Id,Descricao,PrecoMensal,DataInicio,DataFim,ArrendamentoId,HabitacaoServicoOpcionalId")] ArrendamentoHabitacaoServicoOpcional arrendamentoHabitacaoServicoOpcional)
        {
            if (ModelState.IsValid)
            {
                _context.Add(arrendamentoHabitacaoServicoOpcional);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ArrendamentoId"] = new SelectList(_context.Arrendamentos, "Id", "Id", arrendamentoHabitacaoServicoOpcional.ArrendamentoId);
            ViewData["HabitacaoServicoOpcionalId"] = new SelectList(_context.HabitacoesServicos, "Id", "Descricao", arrendamentoHabitacaoServicoOpcional.HabitacaoServicoOpcionalId);
            return View(arrendamentoHabitacaoServicoOpcional);
        }

        // GET: ArrendamentosHabitacoesServicosOpcionais/Edit/5
        [Authorize(Roles = "Administrador, Gestor")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.ArrendamentosHabitacoesServicosOpcionais == null)
            {
                return NotFound();
            }

            var arrendamentoHabitacaoServicoOpcional = await _context.ArrendamentosHabitacoesServicosOpcionais.FindAsync(id);
            if (arrendamentoHabitacaoServicoOpcional == null)
            {
                return NotFound();
            }
            ViewData["ArrendamentoId"] = new SelectList(_context.Arrendamentos, "Id", "Id", arrendamentoHabitacaoServicoOpcional.ArrendamentoId);
            ViewData["HabitacaoServicoOpcionalId"] = new SelectList(_context.HabitacoesServicos, "Id", "Descricao", arrendamentoHabitacaoServicoOpcional.HabitacaoServicoOpcionalId);
            return View(arrendamentoHabitacaoServicoOpcional);
        }

        // POST: ArrendamentosHabitacoesServicosOpcionais/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Administrador, Gestor")]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Descricao,PrecoMensal,DataInicio,DataFim,ArrendamentoId,HabitacaoServicoOpcionalId")] ArrendamentoHabitacaoServicoOpcional arrendamentoHabitacaoServicoOpcional)
        {
            if (id != arrendamentoHabitacaoServicoOpcional.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(arrendamentoHabitacaoServicoOpcional);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ArrendamentoHabitacaoServicoOpcionalExists(arrendamentoHabitacaoServicoOpcional.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ArrendamentoId"] = new SelectList(_context.Arrendamentos, "Id", "Id", arrendamentoHabitacaoServicoOpcional.ArrendamentoId);
            ViewData["HabitacaoServicoOpcionalId"] = new SelectList(_context.HabitacoesServicos, "Id", "Descricao", arrendamentoHabitacaoServicoOpcional.HabitacaoServicoOpcionalId);
            return View(arrendamentoHabitacaoServicoOpcional);
        }

        // GET: ArrendamentosHabitacoesServicosOpcionais/Delete/5
        [Authorize(Roles = "Administrador, Gestor")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.ArrendamentosHabitacoesServicosOpcionais == null)
            {
                return NotFound();
            }

            var arrendamentoHabitacaoServicoOpcional = await _context.ArrendamentosHabitacoesServicosOpcionais
                .Include(a => a.Arrendamento)
                .Include(a => a.HabitacaoServicoOpcional)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (arrendamentoHabitacaoServicoOpcional == null)
            {
                return NotFound();
            }

            return View(arrendamentoHabitacaoServicoOpcional);
        }

        // POST: ArrendamentosHabitacoesServicosOpcionais/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Administrador, Gestor")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.ArrendamentosHabitacoesServicosOpcionais == null)
            {
                return Problem("Entity set 'ApplicationDbContext.ArrendamentosHabitacoesServicosOpcionais'  is null.");
            }
            var arrendamentoHabitacaoServicoOpcional = await _context.ArrendamentosHabitacoesServicosOpcionais.FindAsync(id);
            if (arrendamentoHabitacaoServicoOpcional != null)
            {
                _context.ArrendamentosHabitacoesServicosOpcionais.Remove(arrendamentoHabitacaoServicoOpcional);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ArrendamentoHabitacaoServicoOpcionalExists(int id)
        {
          return (_context.ArrendamentosHabitacoesServicosOpcionais?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}

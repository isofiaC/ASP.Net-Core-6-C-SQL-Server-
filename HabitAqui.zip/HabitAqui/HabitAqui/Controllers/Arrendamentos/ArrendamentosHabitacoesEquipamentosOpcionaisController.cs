﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using HabitAqui.Data;
using HabitAqui.Models.Arrendamentos;
using Microsoft.AspNetCore.Authorization;

namespace HabitAqui.Controllers.Arrendamentos
{
    public class ArrendamentosHabitacoesEquipamentosOpcionaisController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ArrendamentosHabitacoesEquipamentosOpcionaisController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: ArrendamentosHabitacoesEquipamentosOpcionais
        [Authorize(Roles = "Admin, Administrador, Gestor, Funcionario")]
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.ArrendamentosHabitacoesEquipamentosOpcionais.Include(a => a.Arrendamento).Include(a => a.HabitacaoEquipamentoOpcional);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: ArrendamentosHabitacoesEquipamentosOpcionais/Details/5
        [Authorize(Roles = "Admin, Administrador, Gestor, Funcionario")]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.ArrendamentosHabitacoesEquipamentosOpcionais == null)
            {
                return NotFound();
            }

            var arrendamentoHabitacaoEquipamentoOpcional = await _context.ArrendamentosHabitacoesEquipamentosOpcionais
                .Include(a => a.Arrendamento)
                .Include(a => a.HabitacaoEquipamentoOpcional)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (arrendamentoHabitacaoEquipamentoOpcional == null)
            {
                return NotFound();
            }

            return View(arrendamentoHabitacaoEquipamentoOpcional);
        }

        // GET: ArrendamentosHabitacoesEquipamentosOpcionais/Create
        [Authorize(Roles = "Administrador, Gestor, Funcionario")]
        public IActionResult Create()
        {
            ViewData["ArrendamentoId"] = new SelectList(_context.Arrendamentos, "Id", "Id");
            ViewData["HabitacaoEquipamentoOpcionalId"] = new SelectList(_context.HabitacoesEquipamentos, "Id", "Descricao");
            return View();
        }

        // POST: ArrendamentosHabitacoesEquipamentosOpcionais/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Administrador, Gestor, Funcionario")]
        public async Task<IActionResult> Create([Bind("Id,Descricao,AluguerMensal,DataInicio,DataFim,ArrendamentoId,HabitacaoEquipamentoOpcionalId")] ArrendamentoHabitacaoEquipamentoOpcional arrendamentoHabitacaoEquipamentoOpcional)
        {
            if (arrendamentoHabitacaoEquipamentoOpcional.DataInicio >= 
                            arrendamentoHabitacaoEquipamentoOpcional.DataFim 
                    && arrendamentoHabitacaoEquipamentoOpcional.DataFim.HasValue)
            {
                ModelState.AddModelError("DataInicio", "Data de início tem de ser anterior à data de fim.");
            }

            if (ModelState.IsValid)
            {
                _context.Add(arrendamentoHabitacaoEquipamentoOpcional);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ArrendamentoId"] = new SelectList(_context.Arrendamentos, "Id", "Id", arrendamentoHabitacaoEquipamentoOpcional.ArrendamentoId);
            ViewData["HabitacaoEquipamentoOpcionalId"] = new SelectList(_context.HabitacoesEquipamentos, "Id", "Descricao", arrendamentoHabitacaoEquipamentoOpcional.HabitacaoEquipamentoOpcionalId);
            return View(arrendamentoHabitacaoEquipamentoOpcional);
        }

        // GET: ArrendamentosHabitacoesEquipamentosOpcionais/Edit/5
        [Authorize(Roles = "Administrador, Gestor")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.ArrendamentosHabitacoesEquipamentosOpcionais == null)
            {
                return NotFound();
            }

            var arrendamentoHabitacaoEquipamentoOpcional = await _context.ArrendamentosHabitacoesEquipamentosOpcionais.FindAsync(id);
            if (arrendamentoHabitacaoEquipamentoOpcional == null)
            {
                return NotFound();
            }
            ViewData["ArrendamentoId"] = new SelectList(_context.Arrendamentos, "Id", "Id", arrendamentoHabitacaoEquipamentoOpcional.ArrendamentoId);
            ViewData["HabitacaoEquipamentoOpcionalId"] = new SelectList(_context.HabitacoesEquipamentos, "Id", "Descricao", arrendamentoHabitacaoEquipamentoOpcional.HabitacaoEquipamentoOpcionalId);
            return View(arrendamentoHabitacaoEquipamentoOpcional);
        }

        // POST: ArrendamentosHabitacoesEquipamentosOpcionais/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Administrador, Gestor")]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Descricao,AluguerMensal,DataInicio,DataFim,ArrendamentoId,HabitacaoEquipamentoOpcionalId")] ArrendamentoHabitacaoEquipamentoOpcional arrendamentoHabitacaoEquipamentoOpcional)
        {
            if (id != arrendamentoHabitacaoEquipamentoOpcional.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(arrendamentoHabitacaoEquipamentoOpcional);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ArrendamentoHabitacaoEquipamentoOpcionalExists(arrendamentoHabitacaoEquipamentoOpcional.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ArrendamentoId"] = new SelectList(_context.Arrendamentos, "Id", "Id", arrendamentoHabitacaoEquipamentoOpcional.ArrendamentoId);
            ViewData["HabitacaoEquipamentoOpcionalId"] = new SelectList(_context.HabitacoesEquipamentos, "Id", "Descricao", arrendamentoHabitacaoEquipamentoOpcional.HabitacaoEquipamentoOpcionalId);
            return View(arrendamentoHabitacaoEquipamentoOpcional);
        }

        // GET: ArrendamentosHabitacoesEquipamentosOpcionais/Delete/5
        [Authorize(Roles = "Administrador, Gestor")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.ArrendamentosHabitacoesEquipamentosOpcionais == null)
            {
                return NotFound();
            }

            var arrendamentoHabitacaoEquipamentoOpcional = await _context.ArrendamentosHabitacoesEquipamentosOpcionais
                .Include(a => a.Arrendamento)
                .Include(a => a.HabitacaoEquipamentoOpcional)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (arrendamentoHabitacaoEquipamentoOpcional == null)
            {
                return NotFound();
            }

            return View(arrendamentoHabitacaoEquipamentoOpcional);
        }

        // POST: ArrendamentosHabitacoesEquipamentosOpcionais/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Administrador, Gestor")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.ArrendamentosHabitacoesEquipamentosOpcionais == null)
            {
                return Problem("Entity set 'ApplicationDbContext.ArrendamentosHabitacoesEquipamentosOpcionais'  is null.");
            }
            var arrendamentoHabitacaoEquipamentoOpcional = await _context.ArrendamentosHabitacoesEquipamentosOpcionais.FindAsync(id);
            if (arrendamentoHabitacaoEquipamentoOpcional != null)
            {
                _context.ArrendamentosHabitacoesEquipamentosOpcionais.Remove(arrendamentoHabitacaoEquipamentoOpcional);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ArrendamentoHabitacaoEquipamentoOpcionalExists(int id)
        {
          return (_context.ArrendamentosHabitacoesEquipamentosOpcionais?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}

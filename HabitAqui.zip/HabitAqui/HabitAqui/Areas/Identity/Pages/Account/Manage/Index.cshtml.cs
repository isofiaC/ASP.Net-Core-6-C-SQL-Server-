﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.
#nullable disable

using System;
using System.ComponentModel.DataAnnotations;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using HabitAqui.Models.Utilizadores;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HabitAqui.Areas.Identity.Pages.Account.Manage
{
    public class IndexModel : PageModel
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;

        public IndexModel(
            UserManager<ApplicationUser> userManager,
            SignInManager<ApplicationUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }

        /// <summary>
        ///     This API supports the ASP.NET Core Identity default UI infrastructure and is not intended to be used
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        public string Username { get; set; }

        /// <summary>
        ///     This API supports the ASP.NET Core Identity default UI infrastructure and is not intended to be used
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        [TempData]
        public string StatusMessage { get; set; }

        /// <summary>
        ///     This API supports the ASP.NET Core Identity default UI infrastructure and is not intended to be used
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        [BindProperty]
        public InputModel Input { get; set; }

        /// <summary>
        ///     This API supports the ASP.NET Core Identity default UI infrastructure and is not intended to be used
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        public class InputModel
        {
            /// <summary>
            ///     This API supports the ASP.NET Core Identity default UI infrastructure and is not intended to be used
            ///     directly from your code. This API may change or be removed in future releases.
            /// </summary>
            [Display(Name = "Phone number")]
            [Phone]
            public string PhoneNumber { get; set; }

            [Display(Name = "Primeiro Nome")]
            public string PrimeiroNome { get; set; }

            [Display(Name = "Último Nome")]
            public string UltimoNome { get; set; }

            [Display(Name = "Data de Nascimento")]
            [DataType(DataType.Date)]
            public DateTime DataNascimento { get; set; }

            [Display(Name = "NIF")]
            public string Nif { get; set; }

            [Display(Name = "Morada")]
            public string Morada { get; set; }

            [Display(Name = "Código Postal")]
            public string CodigoPostal { get; set; }

            [Display(Name = "Localidade")]
            public string Localidade { get; set; }

            [Display(Name = "País")]
            public string Pais { get; set; }

            [Display(Name = "Telefone")]
            [Phone]
            public string Telefone { get; set; } = string.Empty;

            [Display(Name = "Foto")]
            public string Foto { get; set; }
        }

        private async Task LoadAsync(ApplicationUser user)
        {
            var userName = await _userManager.GetUserNameAsync(user);
            var phoneNumber = await _userManager.GetPhoneNumberAsync(user);
            var Foto = user.Foto;
            Username = userName;

            Input = new InputModel
            {
                PhoneNumber = phoneNumber,
                PrimeiroNome = user.PrimeiroNome,
                UltimoNome = user.UltimoNome,
                DataNascimento = (DateTime)user.DataNascimento,
                Nif = user.Nif,
                Morada = user.Morada,
                CodigoPostal = user.CodigoPostal,
                Localidade = user.Localidade,
                Pais = user.Pais,
                Telefone = user.Telefone,
                Foto = Foto
            };
        }

        public async Task<IActionResult> OnGetAsync()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound($"Unable to load user with ID '{_userManager.GetUserId(User)}'.");
            }

            await LoadAsync(user);
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound($"Unable to load user with ID '{_userManager.GetUserId(User)}'.");
            }

            if (!ModelState.IsValid)
            {
                await LoadAsync(user);
                return Page();
            }

            /*
            var phoneNumber = await _userManager.GetPhoneNumberAsync(user);
            if (Input.PhoneNumber != phoneNumber)
            {
                var setPhoneResult = await _userManager.SetPhoneNumberAsync(user, Input.PhoneNumber);
                if (!setPhoneResult.Succeeded)
                {
                    StatusMessage = "Unexpected error when trying to set phone number.";
                    return RedirectToPage();
                }
            }
            */

            // tudo de uma vez
            user.PrimeiroNome = Input.PrimeiroNome;
            user.UltimoNome = Input.UltimoNome;
            user.DataNascimento = Input.DataNascimento;
            user.Nif = Input.Nif;
            user.Morada = Input.Morada;
            user.CodigoPostal = Input.CodigoPostal;
            user.Localidade = Input.Localidade;
            user.Pais = Input.Pais;
            user.Telefone = Input.Telefone;
            

            // boa prática 
            if (user.PrimeiroNome != Input.PrimeiroNome)
            {
                user.PrimeiroNome = Input.PrimeiroNome;
                await _userManager.UpdateAsync(user);
            }

            if (user.UltimoNome != Input.UltimoNome)
            {
                user.UltimoNome = Input.UltimoNome;
                await _userManager.UpdateAsync(user);
            }

            if (user.DataNascimento != Input.DataNascimento)
            {
                user.DataNascimento = Input.DataNascimento;
                await _userManager.UpdateAsync(user);
            }

            if (user.Nif != Input.Nif)
            {
                user.Nif = Input.Nif;
                await _userManager.UpdateAsync(user);
            }

            if (user.Morada != Input.Morada)
            {
                user.Morada = Input.Morada;
                await _userManager.UpdateAsync(user);
            }

            if (user.CodigoPostal != Input.CodigoPostal)
            {
                user.CodigoPostal = Input.CodigoPostal;
                await _userManager.UpdateAsync(user);
            }

            if (user.Localidade != Input.Localidade)
            {
                user.Localidade = Input.Localidade;
                await _userManager.UpdateAsync(user);
            }

            if (user.Pais != Input.Pais)
            {
                user.Pais = Input.Pais;
                await _userManager.UpdateAsync(user);
            }

            if (user.Telefone != Input.Telefone)
            {
                user.Telefone = Input.Telefone;
                await _userManager.UpdateAsync(user);
            }

            if (Request.Form.Files.Count > 0)
            {
                IFormFile file = Request.Form.Files.FirstOrDefault();
                using (var dataStream = new MemoryStream())
                {
                    await file.CopyToAsync(dataStream);
                    user.Foto = dataStream.ToString();
                }
                await _userManager.UpdateAsync(user);
            }

            await _signInManager.RefreshSignInAsync(user);
            StatusMessage = "O seu perfil foi atualizado";
            return RedirectToPage();
        }
    }
}

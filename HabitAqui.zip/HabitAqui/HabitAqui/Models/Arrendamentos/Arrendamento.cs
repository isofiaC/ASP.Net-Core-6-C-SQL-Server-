﻿using HabitAqui.Models.Habitacoes;
using HabitAqui.Models.Utilizadores;
using System.ComponentModel.DataAnnotations;

namespace HabitAqui.Models.Arrendamentos
{
    public class Arrendamento
    {
        public int Id { get; set; }

        [Display(Name = "Data de Início", Prompt = "Introduza a data de início do arrendamento: yyyy-mm-dd")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
        [Required(ErrorMessage = "Introduza a data de início do arrendamento")]
        public DateTime DataInicio { get; set; }

        [Display(Name = "Data de Fim", Prompt = "Introduza a data do fim do arrendamento: yyyy-mm-dd")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
        public DateTime? DataFim { get; set; }

        [Display(Name = "Renda Mensal", Prompt = "Introduza o valor da renda mensal em euros")]
        [DisplayFormat(DataFormatString = "{0:C, FR-fr}")]
        [Range(0, int.MaxValue, ErrorMessage = "Mínimo: 0")]
        [Required(ErrorMessage = "Introduza o valor da renda mensal em euros")]
        public decimal RendaMensal { get; set; }

        [Display(Name = "Caução", Prompt = "Introduza o valor da caução em euros")]
        [DisplayFormat(DataFormatString = "{0:C, FR-fr}")]
        [Range(0, int.MaxValue, ErrorMessage = "Mínimo: 0")]
        public decimal? Caucao { get; set; }

        [Display(Name = "Data e Hora da Reserva", Prompt = "Introduza a data e hora da reserva: yyyy-MM-ddTHH:mm:ss")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-ddTHH:mm:ss}")]
        [Required(ErrorMessage = "Introduza a data e hora da reserva")]
        public DateTime DataHoraReserva { get; set; }

        [Display(Name = "Observações da Reserva", Prompt = "Introduza as observações da reserva da habitação")]
        [StringLength(1000)]
        public string? ObservacoesReserva { get; set; }

        [Display(Name = "Data e Hora do Cancelamento", Prompt = "Introduza a data e hora do cancelamento: yyyy-MM-ddTHH:mm:ss")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-ddTHH:mm:ss}")]
        public DateTime? DataHoraCancelamento { get; set; }

        [Display(Name = "Observações do Cancelamento", Prompt = "Introduza as observações do cancelamento da reserva")]
        [StringLength(1000)]
        public string? ObservacoesCancelamento { get; set; }

        [Display(Name = "Data e Hora da Entrega", Prompt = "Introduza a data e hora da entrega da habitação: yyyy-MM-ddTHH:mm:ss")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-ddTHH:mm:ss}")]
        public DateTime? DataEntrega { get; set; }

        [Display(Name = "Observações da Entrega", 
            Prompt = "Introduza as observações da entrega da habitação")]
        [StringLength(1000)]
        public string? ObservacoesEntrega { get; set; }

        [Display(Name = "Data e Hora da Receção", Prompt = "Introduza a data e hora da receção da habitação: yyyy-MM-ddTHH:mm:ss")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-ddTHH:mm:ss}")]
        public DateTime? DataRececao { get; set; }

        [Display(Name = "Observações da Receção", Prompt = "Introduza as observações da receção da habitação")]
        [StringLength(1000)]
        public string? ObservacoesRececao { get; set; }


        [Display(Name = "ID da Pré-Reserva", 
            Prompt = "Introduza o ID da pré-reserva do cliente")]
        public int? PreReservaId { get; set; }
        public PreReserva PreReserva { get; set; } = new PreReserva();

        [Display(Name = "ID da Habitação", Prompt = "Introduza o ID da habitação")]
        public int? HabitacaoId { get; set; }
        public Habitacao Habitacao { get; set; } = new Habitacao();

        [Display(Name = "ID do Arrendatário", Prompt = "Introduza o ID do arrendatário")]
        public int? ArrendatarioId { get; set; }
        public Arrendatario Arrendatario { get; set; } = new Arrendatario();

        [Display(Name = "ID do Funcionário", 
            Prompt = "Introduza o ID do funcionário")]
        public int? FuncionarioId { get; set; }
        public Funcionario Funcionario { get; set; } = new Funcionario();

        
        public ICollection<ArrendamentoHabitacaoServicoOpcional> ArrendamentosHabitacoesServicosOpcionais
        { get; set; } = new List<ArrendamentoHabitacaoServicoOpcional>();
        public ICollection<ArrendamentoHabitacaoEquipamentoOpcional> ArrendamentosHabitacoesEquipamentosOpcionais
        { get; set; } = new List<ArrendamentoHabitacaoEquipamentoOpcional>();
    }
}

﻿using HabitAqui.Models.Habitacoes;
using System.ComponentModel.DataAnnotations;
using HabitAqui.Models.Utilizadores;

namespace HabitAqui.Models.Arrendamentos
{
    public class PreReserva
    {
        public int Id { get; set; }

        [Display(Name = "Data de Início", Prompt = "Introduza a data de início pretendida: yyyy-mm-dd")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
        [Required(ErrorMessage = "Introduza a data de início pretendida")]
        public DateTime DataInicio { get; set; }

        [Display(Name = "Data de Fim", Prompt = "Introduza a data de fim pretendida: yyyy-mm-dd")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
        public DateTime? DataFim { get; set; }

        [Display(Name = "Data e Hora da Pré-Reserva", 
            Prompt = "Introduza a data e hora da pré-reserva: yyyy-MM-ddTHH:mm:ss")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-ddTHH:mm:ss}")]
        [Required(ErrorMessage = "Introduza a data e hora da pré-reserva")]
        public DateTime DataHoraPreReserva { get; set; }

        [Display(Name = "Observações", Prompt = "Introduza as observações")]
        [StringLength(1000)]
        public string? Observacoes { get; set; }


        [Display(Name = "ID da Habitação", Prompt = "Introduza o ID da habitação")]
        [Required(ErrorMessage = "Introduza o ID da habitação")]
        public int HabitacaoId { get; set; }
        public Habitacao Habitacao { get; set; } = new Habitacao();

        [Display(Name = "ID do Arrendatário", Prompt = "Introduza o ID do arrendatário")]
        [Required(ErrorMessage = "Introduza o ID do arrendatário")]
        public int ArrendatarioId { get; set; }
        public Arrendatario Arrendatario { get; set; } = new Arrendatario();


        public ICollection<Arrendamento> Arrendamentos { get; set; } = new List<Arrendamento>();
    }
}

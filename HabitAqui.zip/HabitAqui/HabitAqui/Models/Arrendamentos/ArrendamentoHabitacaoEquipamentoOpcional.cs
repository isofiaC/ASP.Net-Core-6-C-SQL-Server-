﻿using HabitAqui.Models.Habitacoes;
using System.ComponentModel.DataAnnotations;

namespace HabitAqui.Models.Arrendamentos
{
    public class ArrendamentoHabitacaoEquipamentoOpcional
    {
        public int Id { get; set; }

        [Display(Name = "Descrição", 
            Prompt = "Introduza a descrição do equipamento opcional associado ao arrendamento da habitação")]
        [Required(ErrorMessage = "Introduza a descrição do equipamento opcional associado ao arrendamento da habitação")]
        [StringLength(500)]
        public string Descricao { get; set; } = string.Empty;

        [Display(Name = "Aluguer Mensal", 
            Prompt = "Introduza o aluguer mensal do equipamento opcional associado ao arrendamento da habitação")]
        [DisplayFormat(DataFormatString = "{0:C, FR-fr}")]
        [Range(0, int.MaxValue, ErrorMessage = "Mínimo: 0")]
        [Required(ErrorMessage = "Introduza o aluguer mensal do equipamento opcional associado ao arrendamento da habitação")]
        public decimal AluguerMensal { get; set; }

        [Display(Name = "Data de Início", Prompt = "Introduza a data de início do aluguer do equipamento: yyyy-mm-dd")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
        [Required(ErrorMessage = "Introduza a data de início do arrendamento")]
        public DateTime DataInicio { get; set; }

        [Display(Name = "Data de Fim", Prompt = "Introduza a data do fim do aluguer do equipamento: yyyy-mm-dd")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
        public DateTime? DataFim { get; set; }

        [Display(Name = "ID do Arrendamento", Prompt = "Introduza o ID do arrendamento")]
        [Required(ErrorMessage = "Introduza o ID do arrendamento")]
        public int ArrendamentoId { get; set; }
        public Arrendamento Arrendamento { get; set; } = new Arrendamento();

        [Display(Name = "ID do Equipamento Opcional da Habitação", 
            Prompt = "Introduza o ID do equipamento opcional da habitação")]
        [Required(ErrorMessage = "Introduza o ID do equipamento opcional da habitação")]
        public int HabitacaoEquipamentoOpcionalId { get; set; }
        public HabitacaoEquipamento HabitacaoEquipamentoOpcional { get; set; } = new HabitacaoEquipamento();
    }
}

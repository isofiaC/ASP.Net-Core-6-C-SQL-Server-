﻿using HabitAqui.Models.Habitacoes;
using HabitAqui.Models.Utilizadores;
using System.ComponentModel.DataAnnotations;

namespace HabitAqui.Models.Arrendamentos
{
    public class Mediador
    {
        public int Id { get; set; }

        [Display(Name = "Nome", Prompt = "Introduza o nome do mediador")]
        [Required(ErrorMessage = "Introduza o nome do mediador")]
        [StringLength(500)]
        public string Nome { get; set; } = string.Empty;

        [Display(Name = "NIF", Prompt = "Introduza o número de contribuinte do mediador")]
        [Required(ErrorMessage = "Introduza o número de contribuinte do mediador")]
        [StringLength(20)]
        public string Nif { get; set; } = string.Empty;

        [Display(Name = "Morada", Prompt = "Introduza a morada do mediador")]
        [Required(ErrorMessage = "Introduza a morada do mediador")]
        [StringLength(500)]
        public string Morada { get; set; } = string.Empty;

        [Display(Name = "Código Postal", Prompt = "Introduza o código postal do mediador")]
        [Required(ErrorMessage = "Introduza o código postal do mediador")]
        [StringLength(20)]
        public string CodigoPostal { get; set; } = string.Empty;

        [Display(Name = "Localidade", Prompt = "Introduza a localidade do mediador")]
        [Required(ErrorMessage = "Introduza a localidade do mediador")]
        [StringLength(200)]
        public string Localidade { get; set; } = string.Empty;

        [Display(Name = "País", Prompt = "Introduza o país do mediador")]
        [Required(ErrorMessage = "Introduza o país do mediador")]
        [StringLength(50)]
        public string Pais { get; set; } = string.Empty;

        [Display(Name = "Telefone", Prompt = "Introduza o telefone do mediador")]
        [Required(ErrorMessage = "Introduza um número de telefone mediador")]
        [Phone(ErrorMessage = "Telefone inválido!")]
        [StringLength(20)]
        public string Telefone { get; set; } = string.Empty;

        [Display(Name = "Email", Prompt = "Introduza o email do mediador")]
        [EmailAddress(ErrorMessage = "Email inválido!")]
        [Required(ErrorMessage = "Introduza um email válido")]
        [StringLength(100)]
        public string Email { get; set; } = string.Empty;

        [Display(Name = "Foto", Prompt = "Introduza a fotografia do locador")]
        public string? Foto { get; set; }

        [Display(Name = "Data de Início de Atividade",
            Prompt = "Introduza a data de início de atividade do mediador: yyyy-mm-dd")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
        public DateTime? InicioAtividade { get; set; }

        [Display(Name = "Ativo",
            Prompt = "Indique se o mediador está ativo (true - verdadeiro) ou não (false - falso)")]
        [Required(ErrorMessage = "Indique se o mediador está ativo (true - verdadeiro) ou não (false - falso)")]
        public bool Ativo { get; set; }


        public ICollection<Administrador> Administradores { get; set; } = new List<Administrador>();
        public ICollection<Gestor> Gestores { get; set; } = new List<Gestor>();
        public ICollection<Funcionario> Funcionarios { get; set; } = new List<Funcionario>();
        public ICollection<Habitacao> Habitacoes { get; set; } = new List<Habitacao>();
    }
}

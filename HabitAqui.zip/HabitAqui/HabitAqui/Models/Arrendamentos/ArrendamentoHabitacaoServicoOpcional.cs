﻿using HabitAqui.Models.Habitacoes;
using System.ComponentModel.DataAnnotations;

namespace HabitAqui.Models.Arrendamentos
{
    public class ArrendamentoHabitacaoServicoOpcional
    {
        public int Id { get; set; }

        [Display(Name = "Descrição", 
            Prompt = "Introduza a descrição do serviço opcional associado ao arrendamento da habitação")]
        [Required(ErrorMessage = "Introduza a descrição do serviço opcional associado ao arrendamento da habitação")]
        [StringLength(500)]
        public string Descricao { get; set; } = string.Empty;

        [Display(Name = "Preço Mensal", 
            Prompt = "Introduza o preço mensal do serviço opcional associado ao arrendamento da habitação")]
        [DisplayFormat(DataFormatString = "{0:C, FR-fr}")]
        [Range(0, int.MaxValue, ErrorMessage = "Mínimo: 0")]
        [Required(ErrorMessage = "Introduza o preço mensal do serviço opcional associado ao arrendamento da habitação")]
        public decimal PrecoMensal { get; set; }

        [Display(Name = "Data de Início", Prompt = "Introduza a data de início do serviço: yyyy-mm-dd")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
        [Required(ErrorMessage = "Introduza a data de início do arrendamento")]
        public DateTime DataInicio { get; set; }

        [Display(Name = "Data de Fim", Prompt = "Introduza a data do fim do serviço: yyyy-mm-dd")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
        public DateTime? DataFim { get; set; }


        [Display(Name = "ID do Arrendamento", Prompt = "Introduza o ID do arrendamento")]
        [Required(ErrorMessage = "Introduza o ID do arrendamento")]
        public int ArrendamentoId { get; set; }
        public Arrendamento Arrendamento { get; set; } = new Arrendamento();

        [Display(Name = "ID do Serviço Opcional da Habitação", 
            Prompt = "Introduza o ID do serviço opcional da habitação")]
        [Required(ErrorMessage = "Introduza o ID do serviço opcional da habitação")]
        public int HabitacaoServicoOpcionalId { get; set; }
        public HabitacaoServico HabitacaoServicoOpcional { get; set; } = new HabitacaoServico();
    }
}

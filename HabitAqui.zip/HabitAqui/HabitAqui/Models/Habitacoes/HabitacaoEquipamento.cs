﻿using HabitAqui.Models.Arrendamentos;
using System.ComponentModel.DataAnnotations;

namespace HabitAqui.Models.Habitacoes
{
    public class HabitacaoEquipamento
    {
        public int Id { get; set; }

        [Display(Name = "Descrição", Prompt = "Introduza a descrição do equipamento da habitação")]
        [Required(ErrorMessage = "Introduza a descrição do equipamento da habitação")]
        [StringLength(500)]
        public string Descricao { get; set; } = string.Empty;

        [Display(Name = "Opcional", 
            Prompt = "Indique se o equipamento da habitação é opcional (true - verdadeiro) ou não (false - falso)")]
        [Required(ErrorMessage = "Indique se o equipamento da habitação é opcional (true - verdadeiro) ou não (false - falso)")]
        public bool Opcional { get; set; }

        [Display(Name = "Aluguer Mensal", Prompt = "Introduza o aluguer mensal do equipamento da habitação")]
        [DisplayFormat(DataFormatString = "{0:C, FR-fr}")]
        [Range(0, int.MaxValue, ErrorMessage = "Mínimo: 0")]
        public decimal? AluguerMensal { get; set; }

        [Display(Name = "Ativo", 
            Prompt = "Indique se o equipamento da habitação está ativo (true - verdadeiro) ou não (false - falso)")]
        [Required(ErrorMessage = "Indique se o equipamento da habitação está ativo (true - verdadeiro) ou não (false - falso)")]
        public bool Ativo { get; set; }


        [Display(Name = "ID da Habitação", Prompt = "Introduza o ID da habitação")]
        [Required(ErrorMessage = "Introduza o ID da habitação")]
        public int HabitacaoId { get; set; }
        public Habitacao Habitacao { get; set; } = new Habitacao();

        [Display(Name = "ID do Equipamento", Prompt = "Introduza o ID do equipamento")]
        [Required(ErrorMessage = "Introduza o ID do equipamento")]
        public int EquipamentoId { get; set; }
        public Equipamento Equipamento { get; set; } = new Equipamento();


        public ICollection<ArrendamentoHabitacaoEquipamentoOpcional> ArrendamentosHabitacoesEquipamentosOpcionais 
        { get; set; } = new List<ArrendamentoHabitacaoEquipamentoOpcional>();
    }
}

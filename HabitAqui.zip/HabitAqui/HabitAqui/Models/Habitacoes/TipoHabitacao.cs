﻿using System.ComponentModel.DataAnnotations;

namespace HabitAqui.Models.Habitacoes
{
    public class TipoHabitacao
    {
        public int Id { get; set; }

        [Display(Name = "Nome", Prompt = "Introduza o nome do tipo de habitação")]
        [Required(ErrorMessage = "Introduza o nome do tipo de habitação")]
        [StringLength(500)]
        public string Nome { get; set; } = string.Empty;

        [Display(Name = "Descrição", Prompt = "Introduza a descrição do tipo de habitação")]
        [StringLength(1000)]
        public string? Descricao { get; set; }

        [Display(Name = "Ativo", 
            Prompt = "Indique se o tipo de habitação está ativo (true - verdadeiro) ou não (false - falso)")]
        [Required(ErrorMessage = "Indique se o tipo de habitação está ativo (true - verdadeiro) ou não (false - falso)")]
        public bool Ativo { get; set; }


        public ICollection<Habitacao> Habitacoes { get; set; } = new List<Habitacao>();
    }
}

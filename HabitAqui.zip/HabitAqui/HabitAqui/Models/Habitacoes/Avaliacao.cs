﻿using HabitAqui.Models.Utilizadores;
using System.ComponentModel.DataAnnotations;

namespace HabitAqui.Models.Habitacoes
{
    public class Avaliacao
    {
        public int Id { get; set; }

        [Display(Name = "Comentário", Prompt = "Introduza o comentário")]
        [StringLength(1000)]
        public string? Comentario { get; set; }

        [Display(Name = "Avaliação Numérica", Prompt = "Introduza a avaliação numérica (0 a 5)")]
        [Range(0, 5, ErrorMessage = "Mínimo: 0; Máximo: 5")]
        [Required(ErrorMessage = "Introduza a avaliação numérica (0 a 5)")]
        public int NumAvaliacao { get; set; }

        [Display(Name = "Data e Hora da Avaliação", Prompt = "Introduza a data e hora da avaliação: yyyy-MM-ddTHH:mm:ss")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-ddTHH:mm:ss}")]
        [Required(ErrorMessage = "Introduza a data e hora da avaliação")]
        public DateTime DataHoraAvaliacao { get; set; }


        [Display(Name = "ID do Arrendatário", Prompt = "Introduza o ID do arrendatário")]
        [Required(ErrorMessage = "Introduza o ID do arrendatário")]
        public int ArrendatarioId { get; set; }
        public Arrendatario Arrendatario { get; set; } = new Arrendatario();

        [Display(Name = "ID da Habitacao", Prompt = "Introduza o ID da habitacao")]
        [Required(ErrorMessage = "Introduza o ID da habitacao")]
        public int HabitacaoId { get; set; }
        public Habitacao Habitacao { get; set; } = new Habitacao();
    }
}

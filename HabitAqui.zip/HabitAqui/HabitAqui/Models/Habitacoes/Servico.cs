﻿using System.ComponentModel.DataAnnotations;

namespace HabitAqui.Models.Habitacoes
{
    public class Servico
    {
        public int Id { get; set; }

        [Display(Name = "Designação", Prompt = "Introduza a designação do serviço")]
        [Required(ErrorMessage = "Introduza a designação do serviço")]
        [StringLength(500)]
        public string Designacao { get; set; } = string.Empty;

        [Display(Name = "Descrição", Prompt = "Introduza a descrição do serviço")]
        [Required(ErrorMessage = "Introduza a descrição do serviço")]
        [StringLength(1000)]
        public string? Descricao { get; set; }

        [Display(Name = "Ativo", 
            Prompt = "Indique se o serviço está ativo (true - verdadeiro) ou não (false - falso)")]
        [Required(ErrorMessage = "Indique se o serviço está ativo (true - verdadeiro) ou não (false - falso)")]
        public bool Ativo { get; set; }


        public ICollection<HabitacaoServico> HabitacoesServicos { get; set; } = new List<HabitacaoServico>();
    }
}

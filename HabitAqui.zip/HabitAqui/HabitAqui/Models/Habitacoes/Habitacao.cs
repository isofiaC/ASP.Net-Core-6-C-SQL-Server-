﻿using HabitAqui.Models.Arrendamentos;
using HabitAqui.Models.Utilizadores;
using System.ComponentModel.DataAnnotations;

namespace HabitAqui.Models.Habitacoes
{
    public class Habitacao
    {
        public int Id { get; set; }

        [Display(Name = "Nome", Prompt = "Introduza o nome da habitação")]
        [Required(ErrorMessage = "Introduza o nome da habitação")]
        [StringLength(500)]
        public string Nome { get; set; } = string.Empty;

        [Display(Name = "Descrição", Prompt = "Introduza a descrição da habitação")]
        [Required(ErrorMessage = "Introduza a descrição da habitação")]
        [StringLength(1000)]
        public string Descricao { get; set; } = string.Empty;

        [Display(Name = "Morada", Prompt = "Introduza a morada da habitação")]
        [Required(ErrorMessage = "Introduza a morada da habitação")]
        [StringLength(500)]
        public string Morada { get; set; } = string.Empty;

        [Display(Name = "Código Postal", Prompt = "Introduza o código postal da habitação")]
        [Required(ErrorMessage = "Introduza o código postal da habitação")]
        [StringLength(20)]
        public string CodigoPostal { get; set; } = string.Empty;

        [Display(Name = "Localidade", Prompt = "Introduza a localidade da habitação")]
        [Required(ErrorMessage = "Introduza a localidade da habitação")]
        [StringLength(200)]
        public string Localidade { get; set; } = string.Empty;

        [Display(Name = "País", Prompt = "Introduza o país da habitação")]
        [Required(ErrorMessage = "Introduza o país da habitação")]
        [StringLength(50)]
        public string Pais { get; set; } = string.Empty;

        [Display(Name = "Renda Mensal", Prompt = "Introduza a renda mensal da habitação")]
        [DisplayFormat(DataFormatString = "{0:C, FR-fr}")]
        [Range(0, int.MaxValue, ErrorMessage = "Mínimo: 0")]
        [Required(ErrorMessage = "Introduza a renda mensal da habitação")]
        public decimal RendaMensal { get; set; }

        [Display(Name = "Caução", Prompt = "Introduza a caução da habitação (a pagar no início do contrato)")]
        [DisplayFormat(DataFormatString = "{0:C, FR-fr}")]
        [Range(0, int.MaxValue, ErrorMessage = "Mínimo: 0")]
        public decimal? Caucao { get; set; }

        [Display(Name = "Área", Prompt = "Introduza a área da habitação")]
        [Required(ErrorMessage = "Introduza a área da habitação")]
        [Range(0, int.MaxValue, ErrorMessage = "Mínimo: 0")]
        public int Area { get; set; }

        [Display(Name = "Número de Quartos", Prompt = "Introduza o número de quartos da habitação")]
        [Range(0, int.MaxValue, ErrorMessage = "Mínimo: 0")]
        [Required(ErrorMessage = "Introduza o número de quartos da habitação")]
        public int NumQuartos { get; set; }

        [Display(Name = "Número de Wcs", Prompt = "Introduza o número de casas de banho da habitação")]
        [Range(0, int.MaxValue, ErrorMessage = "Mínimo: 0")]
        [Required(ErrorMessage = "Introduza o número de casas de banho da habitação")]
        public int NumWcs { get; set; }

        [Display(Name = "Garagem", 
            Prompt = "Indique se a habitação tem garagem (true - verdadeiro) ou não (false - falso)")]
        [Required(ErrorMessage = "Indique se a habitação tem garagem (true - verdadeiro) ou não (false - falso)")]
        public bool Garagem { get; set; }

        [Display(Name = "Número Mínimo de Meses de Arrendamento", 
            Prompt = "Introduza o número mínimo de meses válidos para arrendamento")]
        [Range(1, int.MaxValue, ErrorMessage = "Mínimo: 1")]
        public int? NumMinMesesArrendamento { get; set; }

        [Display(Name = "Número Máximo de Meses de Arrendamento", 
            Prompt = "Introduza o número máximo de meses válidos para arrendamento")]
        [Range(1, int.MaxValue, ErrorMessage = "Mínimo: 1")]
        public int? NumMaxMesesArrendamento { get; set; }

        [Display(Name = "Ano de Construção", Prompt = "Introduza o ano de construção da habitação")]
        public int? AnoConstrucao { get; set; }

        [Display(Name = "Em Destaque",
            Prompt = "Indique se a habitação está em destaque (true - verdadeiro) ou não (false - falso)")]
        [Required(ErrorMessage = "Indique se a habitação está em destaque (true - verdadeiro) ou não (false - falso)")]
        public bool EmDestaque { get; set; }

        [Display(Name = "Ativo", 
            Prompt = "Indique se a habitação está ativa (true - verdadeiro) ou não (false - falso)")]
        [Required(ErrorMessage = "Indique se a habitação está ativa (true - verdadeiro) ou não (false - falso)")]
        public bool Ativo { get; set; }


        [Display(Name = "ID do Tipo de Habitação", Prompt = "Introduza o ID do tipo de habitação")]
        [Required(ErrorMessage = "Introduza o ID do tipo de habitação")]
        public int TipoHabitacaoId { get; set; }
        public TipoHabitacao TipoHabitacao { get; set; } = new TipoHabitacao();

        [Display(Name = "ID do Proprietário", Prompt = "Introduza o ID do proprietário")]
        [Required(ErrorMessage = "Introduza o ID do proprietário")]
        public int ProprietarioId { get; set; }
        public Proprietario Proprietario { get; set; } = new Proprietario();

        [Display(Name = "ID do Mediador", Prompt = "Introduza o ID do mediador")]
        [Required(ErrorMessage = "Introduza o ID do mediador")]
        public int MediadorId { get; set; }
        public Mediador Mediador { get; set; } = new Mediador();


        public ICollection<PreReserva> PreReservas { get; set; } 
            = new List<PreReserva>();
        public ICollection<Arrendamento> Arrendamentos { get; set; } = new List<Arrendamento>();
        public ICollection<HabitacaoEquipamento> HabitacoesEquipamentos { get; set; } 
            = new List<HabitacaoEquipamento>();
        public ICollection<HabitacaoServico> HabitacoesServicos { get; set; } = new List<HabitacaoServico>();
        public ICollection<Avaliacao> Avaliacoes { get; set; } = new List<Avaliacao>();
    }
}

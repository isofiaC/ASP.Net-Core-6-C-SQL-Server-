﻿using HabitAqui.Models.Arrendamentos;
using System.ComponentModel.DataAnnotations;

namespace HabitAqui.Models.Habitacoes
{
    public class HabitacaoServico
    {
        public int Id { get; set; }

        [Display(Name = "Descrição", Prompt = "Introduza a descrição do serviço da habitação")]
        [Required(ErrorMessage = "Introduza a descrição do serviço da habitação")]
        [StringLength(500)]
        public string Descricao { get; set; } = string.Empty;

        [Display(Name = "Opcional", 
            Prompt = "Indique se o serviço da habitação é opcional (true - verdadeiro) ou não (false - falso)")]
        [Required(ErrorMessage = "Indique se o serviço da habitação é opcional (true - verdadeiro) ou não (false - falso)")]
        public bool Opcional { get; set; }

        [Display(Name = "Preço Mensal", Prompt = "Introduza preço mensal do serviço da habitação")]
        [DisplayFormat(DataFormatString = "{0:C, FR-fr}")]
        [Range(0, int.MaxValue, ErrorMessage = "Mínimo: 0")]
        public decimal? PrecoMensal { get; set; }

        [Display(Name = "Ativo", 
            Prompt = "Indique se o serviço da habitação está ativo (true - verdadeiro) ou não (false - falso)")]
        [Required(ErrorMessage = "Indique se o serviço da habitação está ativo (true - verdadeiro) ou não (false - falso)")] 
        public bool Ativo { get; set; }


        [Display(Name = "ID da Habitação", Prompt = "Introduza o ID da habitação")]
        [Required(ErrorMessage = "Introduza o ID da habitação")]
        public int HabitacaoId { get; set; }
        public Habitacao Habitacao { get; set; } = new Habitacao();

        [Display(Name = "ID do Serviço", Prompt = "Introduza o ID do serviço")]
        [Required(ErrorMessage = "Introduza o ID do serviço")]
        public int ServicoId { get; set; }
        public Servico Servico { get; set; } = new Servico();


        public ICollection<ArrendamentoHabitacaoServicoOpcional> ArrendamentosHabitacoesServicosOpcionais
        { get; set; } = new List<ArrendamentoHabitacaoServicoOpcional>();
    }
}

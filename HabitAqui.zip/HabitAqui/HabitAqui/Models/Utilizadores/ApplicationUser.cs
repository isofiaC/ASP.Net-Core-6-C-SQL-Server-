﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace HabitAqui.Models.Utilizadores
{
    public class ApplicationUser : IdentityUser
    {
        [Display(Name = "Primeiro Nome", Prompt = "Introduza o primeiro nome")]
        [Required(ErrorMessage = "Introduza o primeiro nome")]
        [StringLength(100)]
        public string PrimeiroNome { get; set; } = string.Empty;

        [Display(Name = "Último Nome", Prompt = "Introduza o último nome")]
        [Required(ErrorMessage = "Introduza o último nome")]
        [StringLength(100)]
        public string UltimoNome { get; set; } = string.Empty;

        [Display(Name = "Data de Nascimento", Prompt = "Introduza a data de nascimento: yyyy-mm-dd")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
        public DateTime? DataNascimento { get; set; }

        [Display(Name = "NIF", Prompt = "Introduza o número de contribuinte")]
        [Required(ErrorMessage = "Introduza o número de contribuinte")]
        [StringLength(20)]
        public string Nif { get; set; } = string.Empty;

        [Display(Name = "Morada", Prompt = "Introduza a morada")]
        [Required(ErrorMessage = "Introduza a morada")]
        [StringLength(500)]
        public string Morada { get; set; } = string.Empty;

        [Display(Name = "Código Postal", Prompt = "Introduza o código postal")]
        [Required(ErrorMessage = "Introduza o código postal")]
        [StringLength(20)]
        public string CodigoPostal { get; set; } = string.Empty;

        [Display(Name = "Localidade", Prompt = "Introduza a localidade")]
        [Required(ErrorMessage = "Introduza a localidade")]
        [StringLength(200)]
        public string Localidade { get; set; } = string.Empty;

        [Display(Name = "País", Prompt = "Introduza o país")]
        [Required(ErrorMessage = "Introduza o país")]
        [StringLength(50)]
        public string Pais { get; set; } = string.Empty;

        [Display(Name = "Telefone", Prompt = "Introduza o telefone")]
        [Required(ErrorMessage = "Introduza um número de telefone válido")]
        [Phone(ErrorMessage = "Telefone inválido!")]
        [StringLength(20)]
        public string Telefone { get; set; } = string.Empty;

        [Display(Name = "Foto", Prompt = "Introduza a fotografia")]
        public string? Foto { get; set; }


        public ICollection<Administrador> Administradores { get; set; } = new List<Administrador>();
        public ICollection<Gestor> Gestores { get; set; } = new List<Gestor>();
        public ICollection<Funcionario> Funcionarios { get; set; } = new List<Funcionario>();
        public ICollection<Proprietario> Proprietarios { get; set; } = new List<Proprietario>();
        public ICollection<Arrendatario> Arrendatarios { get; set; } = new List<Arrendatario>();
    }
}

﻿using HabitAqui.Models.Arrendamentos;
using System.ComponentModel.DataAnnotations;

namespace HabitAqui.Models.Utilizadores
{
    public class Administrador
    {
        public int Id { get; set; }

        [Display(Name = "Ativo",
            Prompt = "Indique se o administrador está ativo (true - verdadeiro) ou não (false - falso)")]
        [Required(ErrorMessage = "Indique se o administrador está ativo (true - verdadeiro) ou não (false - falso)!")]
        public bool Ativo { get; set; }


        [Display(Name = "ID do Utilizador", Prompt = "Introduza o ID do utilizador")]
        [Required(ErrorMessage = "Introduza o ID do utilizador")]
        public string ApplicationUserId { get; set; } = string.Empty;
        public ApplicationUser ApplicationUser { get; set; } = new ApplicationUser();

        [Display(Name = "ID do Mediador", Prompt = "Introduza o ID do mediador")]
        [Required(ErrorMessage = "Introduza o ID do mediador")]
        public int MediadorId { get; set; }
        public Mediador Mediador { get; set; } = new Mediador();
    }
}

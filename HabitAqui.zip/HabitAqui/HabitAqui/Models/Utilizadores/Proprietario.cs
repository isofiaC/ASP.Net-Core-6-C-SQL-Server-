﻿using HabitAqui.Models.Arrendamentos;
using HabitAqui.Models.Habitacoes;
using System.ComponentModel.DataAnnotations;

namespace HabitAqui.Models.Utilizadores
{
    public class Proprietario
    {
        public int Id { get; set; }

        [Display(Name = "Ativo",
            Prompt = "Indique se o proprietário está ativo (true - verdadeiro) ou não (false - falso)")]
        [Required(ErrorMessage = "Indique se o proprietário está ativo (true - verdadeiro) ou não (false - falso)")]
        public bool Ativo { get; set; }


        [Display(Name = "ID do Utilizador", Prompt = "Introduza o ID do utilizador")]
        [Required(ErrorMessage = "Introduza o ID do utilizador")]
        public string ApplicationUserId { get; set; } = string.Empty;
        public ApplicationUser ApplicationUser { get; set; } = new ApplicationUser();

        public ICollection<Habitacao> Habitacoes { get; set; } = new List<Habitacao>();
    }
}

﻿using HabitAqui.Models.Arrendamentos;
using HabitAqui.Models.Habitacoes;
using System.ComponentModel.DataAnnotations;

namespace HabitAqui.Models.Utilizadores
{
    public class Arrendatario
    {
        public int Id { get; set; }

        [Display(Name = "Ativo",
            Prompt = "Indique se o arrendatário está ativo (true - verdadeiro) ou não (false - falso)")]
        [Required(ErrorMessage = "Indique se o arrendatário está ativo (true - verdadeiro) ou não (false - falso)!")]
        public bool Ativo { get; set; }


        [Display(Name = "ID do Utilizador", Prompt = "Introduza o ID do utilizador")]
        [Required(ErrorMessage = "Introduza o ID do utilizador")]
        public string ApplicationUserId { get; set; } = string.Empty;
        public ApplicationUser ApplicationUser { get; set; } = new ApplicationUser();


        public ICollection<PreReserva> PreReservas { get; set; }
            = new List<PreReserva>();
        public ICollection<Arrendamento> Arrendamentos { get; set; } = new List<Arrendamento>();
        public ICollection<Avaliacao> Avaliacoes { get; set; } = new List<Avaliacao>();
    }
}

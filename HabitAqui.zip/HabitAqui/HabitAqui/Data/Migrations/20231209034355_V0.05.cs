﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HabitAqui.Data.Migrations
{
    public partial class V005 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Arrendamentos_Clientes_ClienteId",
                table: "Arrendamentos");

            migrationBuilder.DropForeignKey(
                name: "FK_Arrendamentos_Funcionarios_FuncionarioEntregaId",
                table: "Arrendamentos");

            migrationBuilder.DropForeignKey(
                name: "FK_Arrendamentos_Funcionarios_FuncionarioId1",
                table: "Arrendamentos");

            migrationBuilder.DropForeignKey(
                name: "FK_Arrendamentos_Funcionarios_FuncionarioId2",
                table: "Arrendamentos");

            migrationBuilder.DropForeignKey(
                name: "FK_Arrendamentos_Funcionarios_FuncionarioRececaoId",
                table: "Arrendamentos");

            migrationBuilder.DropForeignKey(
                name: "FK_Arrendamentos_Funcionarios_FuncionarioReservaId",
                table: "Arrendamentos");

            migrationBuilder.DropForeignKey(
                name: "FK_Arrendamentos_ManifestacoesInteresse_ManifestacaoInteresseId",
                table: "Arrendamentos");

            migrationBuilder.DropForeignKey(
                name: "FK_Funcionarios_Locadores_LocadorId",
                table: "Funcionarios");

            migrationBuilder.DropForeignKey(
                name: "FK_Gestores_Locadores_LocadorId",
                table: "Gestores");

            migrationBuilder.DropForeignKey(
                name: "FK_Habitacoes_Locadores_LocadorId",
                table: "Habitacoes");

            migrationBuilder.DropTable(
                name: "Admins");

            migrationBuilder.DropTable(
                name: "AvaliacoesHabitacoes");

            migrationBuilder.DropTable(
                name: "AvaliacoesLocadores");

            migrationBuilder.DropTable(
                name: "FotosDanosHabitacoes");

            migrationBuilder.DropTable(
                name: "FotosHabitacoes");

            migrationBuilder.DropTable(
                name: "ManifestacoesInteresse");

            migrationBuilder.DropTable(
                name: "Locadores");

            migrationBuilder.DropTable(
                name: "Clientes");

            migrationBuilder.DropIndex(
                name: "IX_Arrendamentos_ClienteId",
                table: "Arrendamentos");

            migrationBuilder.DropIndex(
                name: "IX_Arrendamentos_FuncionarioEntregaId",
                table: "Arrendamentos");

            migrationBuilder.DropIndex(
                name: "IX_Arrendamentos_FuncionarioId1",
                table: "Arrendamentos");

            migrationBuilder.DropIndex(
                name: "IX_Arrendamentos_FuncionarioRececaoId",
                table: "Arrendamentos");

            migrationBuilder.DropIndex(
                name: "IX_Arrendamentos_FuncionarioReservaId",
                table: "Arrendamentos");

            migrationBuilder.DropColumn(
                name: "Foto",
                table: "Equipamentos");

            migrationBuilder.DropColumn(
                name: "ClienteId",
                table: "Arrendamentos");

            migrationBuilder.DropColumn(
                name: "DataHoraRejeicao",
                table: "Arrendamentos");

            migrationBuilder.DropColumn(
                name: "FuncionarioEntregaId",
                table: "Arrendamentos");

            migrationBuilder.DropColumn(
                name: "FuncionarioId1",
                table: "Arrendamentos");

            migrationBuilder.DropColumn(
                name: "FuncionarioRececaoId",
                table: "Arrendamentos");

            migrationBuilder.DropColumn(
                name: "FuncionarioReservaId",
                table: "Arrendamentos");

            migrationBuilder.RenameColumn(
                name: "Disponivel",
                table: "TiposHabitacoes",
                newName: "Ativo");

            migrationBuilder.RenameColumn(
                name: "Disponivel",
                table: "Servicos",
                newName: "Ativo");

            migrationBuilder.RenameColumn(
                name: "Preco",
                table: "HabitacoesServicos",
                newName: "PrecoMensal");

            migrationBuilder.RenameColumn(
                name: "Disponivel",
                table: "HabitacoesServicos",
                newName: "Ativo");

            migrationBuilder.RenameColumn(
                name: "Preco",
                table: "HabitacoesEquipamentos",
                newName: "AluguerMensal");

            migrationBuilder.RenameColumn(
                name: "Disponivel",
                table: "HabitacoesEquipamentos",
                newName: "Ativo");

            migrationBuilder.RenameColumn(
                name: "Renda",
                table: "Habitacoes",
                newName: "RendaMensal");

            migrationBuilder.RenameColumn(
                name: "LocadorId",
                table: "Habitacoes",
                newName: "ProprietarioId");

            migrationBuilder.RenameIndex(
                name: "IX_Habitacoes_LocadorId",
                table: "Habitacoes",
                newName: "IX_Habitacoes_ProprietarioId");

            migrationBuilder.RenameColumn(
                name: "LocadorId",
                table: "Gestores",
                newName: "MediadorId");

            migrationBuilder.RenameIndex(
                name: "IX_Gestores_LocadorId",
                table: "Gestores",
                newName: "IX_Gestores_MediadorId");

            migrationBuilder.RenameColumn(
                name: "LocadorId",
                table: "Funcionarios",
                newName: "MediadorId");

            migrationBuilder.RenameIndex(
                name: "IX_Funcionarios_LocadorId",
                table: "Funcionarios",
                newName: "IX_Funcionarios_MediadorId");

            migrationBuilder.RenameColumn(
                name: "Disponivel",
                table: "Equipamentos",
                newName: "Ativo");

            migrationBuilder.RenameColumn(
                name: "Preco",
                table: "ArrendamentosHabitacoesServicosOpcionais",
                newName: "PrecoMensal");

            migrationBuilder.RenameColumn(
                name: "Preco",
                table: "ArrendamentosHabitacoesEquipamentosOpcionais",
                newName: "AluguerMensal");

            migrationBuilder.RenameColumn(
                name: "Renda",
                table: "Arrendamentos",
                newName: "RendaMensal");

            migrationBuilder.RenameColumn(
                name: "ManifestacaoInteresseId",
                table: "Arrendamentos",
                newName: "PreReservaId");

            migrationBuilder.RenameColumn(
                name: "FuncionarioId2",
                table: "Arrendamentos",
                newName: "ArrendatarioId");

            migrationBuilder.RenameColumn(
                name: "DanosHabitacaoRececao",
                table: "Arrendamentos",
                newName: "ObservacoesReserva");

            migrationBuilder.RenameColumn(
                name: "DanosHabitacaoEntrega",
                table: "Arrendamentos",
                newName: "ObservacoesCancelamento");

            migrationBuilder.RenameIndex(
                name: "IX_Arrendamentos_ManifestacaoInteresseId",
                table: "Arrendamentos",
                newName: "IX_Arrendamentos_PreReservaId");

            migrationBuilder.RenameIndex(
                name: "IX_Arrendamentos_FuncionarioId2",
                table: "Arrendamentos",
                newName: "IX_Arrendamentos_ArrendatarioId");

            migrationBuilder.AddColumn<int>(
                name: "MediadorId",
                table: "Habitacoes",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<DateTime>(
                name: "DataFim",
                table: "ArrendamentosHabitacoesServicosOpcionais",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "DataInicio",
                table: "ArrendamentosHabitacoesServicosOpcionais",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "DataFim",
                table: "ArrendamentosHabitacoesEquipamentosOpcionais",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "DataInicio",
                table: "ArrendamentosHabitacoesEquipamentosOpcionais",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.CreateTable(
                name: "Arrendatarios",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Ativo = table.Column<bool>(type: "bit", nullable: false),
                    ApplicationUserId = table.Column<string>(type: "nvarchar(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Arrendatarios", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Arrendatarios_AspNetUsers_ApplicationUserId",
                        column: x => x.ApplicationUserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Mediadores",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nome = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    Nif = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Morada = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    CodigoPostal = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Localidade = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Pais = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Telefone = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Foto = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    InicioAtividade = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Ativo = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Mediadores", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Proprietarios",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Ativo = table.Column<bool>(type: "bit", nullable: false),
                    ApplicationUserId = table.Column<string>(type: "nvarchar(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Proprietarios", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Proprietarios_AspNetUsers_ApplicationUserId",
                        column: x => x.ApplicationUserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Avaliacoes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Comentario = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    NumAvaliacao = table.Column<int>(type: "int", nullable: false),
                    DataHoraAvaliacao = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ArrendatarioId = table.Column<int>(type: "int", nullable: false),
                    HabitacaoId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Avaliacoes", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Avaliacoes_Arrendatarios_ArrendatarioId",
                        column: x => x.ArrendatarioId,
                        principalTable: "Arrendatarios",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Avaliacoes_Habitacoes_HabitacaoId",
                        column: x => x.HabitacaoId,
                        principalTable: "Habitacoes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PreReservas",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DataInicio = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DataFim = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DataHoraPreReserva = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Observacoes = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    HabitacaoId = table.Column<int>(type: "int", nullable: false),
                    ArrendatarioId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PreReservas", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PreReservas_Arrendatarios_ArrendatarioId",
                        column: x => x.ArrendatarioId,
                        principalTable: "Arrendatarios",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PreReservas_Habitacoes_HabitacaoId",
                        column: x => x.HabitacaoId,
                        principalTable: "Habitacoes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Administradores",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Ativo = table.Column<bool>(type: "bit", nullable: false),
                    ApplicationUserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    MediadorId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Administradores", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Administradores_AspNetUsers_ApplicationUserId",
                        column: x => x.ApplicationUserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Administradores_Mediadores_MediadorId",
                        column: x => x.MediadorId,
                        principalTable: "Mediadores",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Habitacoes_MediadorId",
                table: "Habitacoes",
                column: "MediadorId");

            migrationBuilder.CreateIndex(
                name: "IX_Administradores_ApplicationUserId",
                table: "Administradores",
                column: "ApplicationUserId");

            migrationBuilder.CreateIndex(
                name: "IX_Administradores_MediadorId",
                table: "Administradores",
                column: "MediadorId");

            migrationBuilder.CreateIndex(
                name: "IX_Arrendatarios_ApplicationUserId",
                table: "Arrendatarios",
                column: "ApplicationUserId");

            migrationBuilder.CreateIndex(
                name: "IX_Avaliacoes_ArrendatarioId",
                table: "Avaliacoes",
                column: "ArrendatarioId");

            migrationBuilder.CreateIndex(
                name: "IX_Avaliacoes_HabitacaoId",
                table: "Avaliacoes",
                column: "HabitacaoId");

            migrationBuilder.CreateIndex(
                name: "IX_PreReservas_ArrendatarioId",
                table: "PreReservas",
                column: "ArrendatarioId");

            migrationBuilder.CreateIndex(
                name: "IX_PreReservas_HabitacaoId",
                table: "PreReservas",
                column: "HabitacaoId");

            migrationBuilder.CreateIndex(
                name: "IX_Proprietarios_ApplicationUserId",
                table: "Proprietarios",
                column: "ApplicationUserId");

            migrationBuilder.AddForeignKey(
                name: "FK_Arrendamentos_Arrendatarios_ArrendatarioId",
                table: "Arrendamentos",
                column: "ArrendatarioId",
                principalTable: "Arrendatarios",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Arrendamentos_PreReservas_PreReservaId",
                table: "Arrendamentos",
                column: "PreReservaId",
                principalTable: "PreReservas",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Funcionarios_Mediadores_MediadorId",
                table: "Funcionarios",
                column: "MediadorId",
                principalTable: "Mediadores",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Gestores_Mediadores_MediadorId",
                table: "Gestores",
                column: "MediadorId",
                principalTable: "Mediadores",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Habitacoes_Mediadores_MediadorId",
                table: "Habitacoes",
                column: "MediadorId",
                principalTable: "Mediadores",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Habitacoes_Proprietarios_ProprietarioId",
                table: "Habitacoes",
                column: "ProprietarioId",
                principalTable: "Proprietarios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Arrendamentos_Arrendatarios_ArrendatarioId",
                table: "Arrendamentos");

            migrationBuilder.DropForeignKey(
                name: "FK_Arrendamentos_PreReservas_PreReservaId",
                table: "Arrendamentos");

            migrationBuilder.DropForeignKey(
                name: "FK_Funcionarios_Mediadores_MediadorId",
                table: "Funcionarios");

            migrationBuilder.DropForeignKey(
                name: "FK_Gestores_Mediadores_MediadorId",
                table: "Gestores");

            migrationBuilder.DropForeignKey(
                name: "FK_Habitacoes_Mediadores_MediadorId",
                table: "Habitacoes");

            migrationBuilder.DropForeignKey(
                name: "FK_Habitacoes_Proprietarios_ProprietarioId",
                table: "Habitacoes");

            migrationBuilder.DropTable(
                name: "Administradores");

            migrationBuilder.DropTable(
                name: "Avaliacoes");

            migrationBuilder.DropTable(
                name: "PreReservas");

            migrationBuilder.DropTable(
                name: "Proprietarios");

            migrationBuilder.DropTable(
                name: "Mediadores");

            migrationBuilder.DropTable(
                name: "Arrendatarios");

            migrationBuilder.DropIndex(
                name: "IX_Habitacoes_MediadorId",
                table: "Habitacoes");

            migrationBuilder.DropColumn(
                name: "MediadorId",
                table: "Habitacoes");

            migrationBuilder.DropColumn(
                name: "DataFim",
                table: "ArrendamentosHabitacoesServicosOpcionais");

            migrationBuilder.DropColumn(
                name: "DataInicio",
                table: "ArrendamentosHabitacoesServicosOpcionais");

            migrationBuilder.DropColumn(
                name: "DataFim",
                table: "ArrendamentosHabitacoesEquipamentosOpcionais");

            migrationBuilder.DropColumn(
                name: "DataInicio",
                table: "ArrendamentosHabitacoesEquipamentosOpcionais");

            migrationBuilder.RenameColumn(
                name: "Ativo",
                table: "TiposHabitacoes",
                newName: "Disponivel");

            migrationBuilder.RenameColumn(
                name: "Ativo",
                table: "Servicos",
                newName: "Disponivel");

            migrationBuilder.RenameColumn(
                name: "PrecoMensal",
                table: "HabitacoesServicos",
                newName: "Preco");

            migrationBuilder.RenameColumn(
                name: "Ativo",
                table: "HabitacoesServicos",
                newName: "Disponivel");

            migrationBuilder.RenameColumn(
                name: "Ativo",
                table: "HabitacoesEquipamentos",
                newName: "Disponivel");

            migrationBuilder.RenameColumn(
                name: "AluguerMensal",
                table: "HabitacoesEquipamentos",
                newName: "Preco");

            migrationBuilder.RenameColumn(
                name: "RendaMensal",
                table: "Habitacoes",
                newName: "Renda");

            migrationBuilder.RenameColumn(
                name: "ProprietarioId",
                table: "Habitacoes",
                newName: "LocadorId");

            migrationBuilder.RenameIndex(
                name: "IX_Habitacoes_ProprietarioId",
                table: "Habitacoes",
                newName: "IX_Habitacoes_LocadorId");

            migrationBuilder.RenameColumn(
                name: "MediadorId",
                table: "Gestores",
                newName: "LocadorId");

            migrationBuilder.RenameIndex(
                name: "IX_Gestores_MediadorId",
                table: "Gestores",
                newName: "IX_Gestores_LocadorId");

            migrationBuilder.RenameColumn(
                name: "MediadorId",
                table: "Funcionarios",
                newName: "LocadorId");

            migrationBuilder.RenameIndex(
                name: "IX_Funcionarios_MediadorId",
                table: "Funcionarios",
                newName: "IX_Funcionarios_LocadorId");

            migrationBuilder.RenameColumn(
                name: "Ativo",
                table: "Equipamentos",
                newName: "Disponivel");

            migrationBuilder.RenameColumn(
                name: "PrecoMensal",
                table: "ArrendamentosHabitacoesServicosOpcionais",
                newName: "Preco");

            migrationBuilder.RenameColumn(
                name: "AluguerMensal",
                table: "ArrendamentosHabitacoesEquipamentosOpcionais",
                newName: "Preco");

            migrationBuilder.RenameColumn(
                name: "RendaMensal",
                table: "Arrendamentos",
                newName: "Renda");

            migrationBuilder.RenameColumn(
                name: "PreReservaId",
                table: "Arrendamentos",
                newName: "ManifestacaoInteresseId");

            migrationBuilder.RenameColumn(
                name: "ObservacoesReserva",
                table: "Arrendamentos",
                newName: "DanosHabitacaoRececao");

            migrationBuilder.RenameColumn(
                name: "ObservacoesCancelamento",
                table: "Arrendamentos",
                newName: "DanosHabitacaoEntrega");

            migrationBuilder.RenameColumn(
                name: "ArrendatarioId",
                table: "Arrendamentos",
                newName: "FuncionarioId2");

            migrationBuilder.RenameIndex(
                name: "IX_Arrendamentos_PreReservaId",
                table: "Arrendamentos",
                newName: "IX_Arrendamentos_ManifestacaoInteresseId");

            migrationBuilder.RenameIndex(
                name: "IX_Arrendamentos_ArrendatarioId",
                table: "Arrendamentos",
                newName: "IX_Arrendamentos_FuncionarioId2");

            migrationBuilder.AddColumn<string>(
                name: "Foto",
                table: "Equipamentos",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ClienteId",
                table: "Arrendamentos",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "DataHoraRejeicao",
                table: "Arrendamentos",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "FuncionarioEntregaId",
                table: "Arrendamentos",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "FuncionarioId1",
                table: "Arrendamentos",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "FuncionarioRececaoId",
                table: "Arrendamentos",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "FuncionarioReservaId",
                table: "Arrendamentos",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "Admins",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ApplicationUserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Ativo = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Admins", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Admins_AspNetUsers_ApplicationUserId",
                        column: x => x.ApplicationUserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Clientes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ApplicationUserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Ativo = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Clientes", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Clientes_AspNetUsers_ApplicationUserId",
                        column: x => x.ApplicationUserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "FotosDanosHabitacoes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ArrendamentoId = table.Column<int>(type: "int", nullable: false),
                    Descricao = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    Foto = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FotosDanosHabitacoes", x => x.Id);
                    table.ForeignKey(
                        name: "FK_FotosDanosHabitacoes_Arrendamentos_ArrendamentoId",
                        column: x => x.ArrendamentoId,
                        principalTable: "Arrendamentos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "FotosHabitacoes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HabitacaoId = table.Column<int>(type: "int", nullable: false),
                    Descricao = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    EmDestaque = table.Column<bool>(type: "bit", nullable: true),
                    Foto = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FotosHabitacoes", x => x.Id);
                    table.ForeignKey(
                        name: "FK_FotosHabitacoes_Habitacoes_HabitacaoId",
                        column: x => x.HabitacaoId,
                        principalTable: "Habitacoes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Locadores",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Ativo = table.Column<bool>(type: "bit", nullable: false),
                    CodigoPostal = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Empresa = table.Column<bool>(type: "bit", nullable: false),
                    Foto = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    InicioAtividade = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Localidade = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Morada = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    Nif = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Nome = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    Pais = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Telefone = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Locadores", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AvaliacoesHabitacoes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ClienteId = table.Column<int>(type: "int", nullable: false),
                    HabitacaoId = table.Column<int>(type: "int", nullable: false),
                    Avaliacao = table.Column<int>(type: "int", nullable: false),
                    Comentario = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AvaliacoesHabitacoes", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AvaliacoesHabitacoes_Clientes_ClienteId",
                        column: x => x.ClienteId,
                        principalTable: "Clientes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AvaliacoesHabitacoes_Habitacoes_HabitacaoId",
                        column: x => x.HabitacaoId,
                        principalTable: "Habitacoes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ManifestacoesInteresse",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ClienteId = table.Column<int>(type: "int", nullable: false),
                    HabitacaoId = table.Column<int>(type: "int", nullable: false),
                    DataFim = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DataHoraInteresse = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DataInicio = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Observacoes = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ManifestacoesInteresse", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ManifestacoesInteresse_Clientes_ClienteId",
                        column: x => x.ClienteId,
                        principalTable: "Clientes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ManifestacoesInteresse_Habitacoes_HabitacaoId",
                        column: x => x.HabitacaoId,
                        principalTable: "Habitacoes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AvaliacoesLocadores",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ClienteId = table.Column<int>(type: "int", nullable: false),
                    LocadorId = table.Column<int>(type: "int", nullable: false),
                    Avaliacao = table.Column<int>(type: "int", nullable: false),
                    Comentario = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AvaliacoesLocadores", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AvaliacoesLocadores_Clientes_ClienteId",
                        column: x => x.ClienteId,
                        principalTable: "Clientes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AvaliacoesLocadores_Locadores_LocadorId",
                        column: x => x.LocadorId,
                        principalTable: "Locadores",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Arrendamentos_ClienteId",
                table: "Arrendamentos",
                column: "ClienteId");

            migrationBuilder.CreateIndex(
                name: "IX_Arrendamentos_FuncionarioEntregaId",
                table: "Arrendamentos",
                column: "FuncionarioEntregaId");

            migrationBuilder.CreateIndex(
                name: "IX_Arrendamentos_FuncionarioId1",
                table: "Arrendamentos",
                column: "FuncionarioId1");

            migrationBuilder.CreateIndex(
                name: "IX_Arrendamentos_FuncionarioRececaoId",
                table: "Arrendamentos",
                column: "FuncionarioRececaoId");

            migrationBuilder.CreateIndex(
                name: "IX_Arrendamentos_FuncionarioReservaId",
                table: "Arrendamentos",
                column: "FuncionarioReservaId");

            migrationBuilder.CreateIndex(
                name: "IX_Admins_ApplicationUserId",
                table: "Admins",
                column: "ApplicationUserId");

            migrationBuilder.CreateIndex(
                name: "IX_AvaliacoesHabitacoes_ClienteId",
                table: "AvaliacoesHabitacoes",
                column: "ClienteId");

            migrationBuilder.CreateIndex(
                name: "IX_AvaliacoesHabitacoes_HabitacaoId",
                table: "AvaliacoesHabitacoes",
                column: "HabitacaoId");

            migrationBuilder.CreateIndex(
                name: "IX_AvaliacoesLocadores_ClienteId",
                table: "AvaliacoesLocadores",
                column: "ClienteId");

            migrationBuilder.CreateIndex(
                name: "IX_AvaliacoesLocadores_LocadorId",
                table: "AvaliacoesLocadores",
                column: "LocadorId");

            migrationBuilder.CreateIndex(
                name: "IX_Clientes_ApplicationUserId",
                table: "Clientes",
                column: "ApplicationUserId");

            migrationBuilder.CreateIndex(
                name: "IX_FotosDanosHabitacoes_ArrendamentoId",
                table: "FotosDanosHabitacoes",
                column: "ArrendamentoId");

            migrationBuilder.CreateIndex(
                name: "IX_FotosHabitacoes_HabitacaoId",
                table: "FotosHabitacoes",
                column: "HabitacaoId");

            migrationBuilder.CreateIndex(
                name: "IX_ManifestacoesInteresse_ClienteId",
                table: "ManifestacoesInteresse",
                column: "ClienteId");

            migrationBuilder.CreateIndex(
                name: "IX_ManifestacoesInteresse_HabitacaoId",
                table: "ManifestacoesInteresse",
                column: "HabitacaoId");

            migrationBuilder.AddForeignKey(
                name: "FK_Arrendamentos_Clientes_ClienteId",
                table: "Arrendamentos",
                column: "ClienteId",
                principalTable: "Clientes",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Arrendamentos_Funcionarios_FuncionarioEntregaId",
                table: "Arrendamentos",
                column: "FuncionarioEntregaId",
                principalTable: "Funcionarios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Arrendamentos_Funcionarios_FuncionarioId1",
                table: "Arrendamentos",
                column: "FuncionarioId1",
                principalTable: "Funcionarios",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Arrendamentos_Funcionarios_FuncionarioId2",
                table: "Arrendamentos",
                column: "FuncionarioId2",
                principalTable: "Funcionarios",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Arrendamentos_Funcionarios_FuncionarioRececaoId",
                table: "Arrendamentos",
                column: "FuncionarioRececaoId",
                principalTable: "Funcionarios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Arrendamentos_Funcionarios_FuncionarioReservaId",
                table: "Arrendamentos",
                column: "FuncionarioReservaId",
                principalTable: "Funcionarios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Arrendamentos_ManifestacoesInteresse_ManifestacaoInteresseId",
                table: "Arrendamentos",
                column: "ManifestacaoInteresseId",
                principalTable: "ManifestacoesInteresse",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Funcionarios_Locadores_LocadorId",
                table: "Funcionarios",
                column: "LocadorId",
                principalTable: "Locadores",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Gestores_Locadores_LocadorId",
                table: "Gestores",
                column: "LocadorId",
                principalTable: "Locadores",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Habitacoes_Locadores_LocadorId",
                table: "Habitacoes",
                column: "LocadorId",
                principalTable: "Locadores",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}

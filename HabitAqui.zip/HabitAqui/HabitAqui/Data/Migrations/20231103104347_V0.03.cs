﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HabitAqui.Data.Migrations
{
    public partial class V003 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "Descricao",
                table: "TiposHabitacoes",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Descricao",
                table: "Servicos",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<DateTime>(
                name: "InicioAtividade",
                table: "Locadores",
                type: "datetime2",
                nullable: true,
                oldClrType: typeof(DateTime),
                oldType: "datetime2");

            migrationBuilder.AlterColumn<string>(
                name: "Foto",
                table: "Locadores",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Morada",
                table: "Gestores",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Localidade",
                table: "Gestores",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Foto",
                table: "Gestores",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "CodigoPostal",
                table: "Gestores",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Morada",
                table: "Funcionarios",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Localidade",
                table: "Funcionarios",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Foto",
                table: "Funcionarios",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "CodigoPostal",
                table: "Funcionarios",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Descricao",
                table: "Equipamentos",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Foto",
                table: "Clientes",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.CreateTable(
                name: "ManifestacoesInteresse",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DataInicio = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DataFim = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DataHoraInteresse = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Observacoes = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    HabitacaoId = table.Column<int>(type: "int", nullable: false),
                    ClienteId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ManifestacoesInteresse", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ManifestacoesInteresse_Clientes_ClienteId",
                        column: x => x.ClienteId,
                        principalTable: "Clientes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ManifestacoesInteresse_Habitacoes_HabitacaoId",
                        column: x => x.HabitacaoId,
                        principalTable: "Habitacoes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Arrendamentos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DataInicio = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DataFim = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Renda = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Caucao = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    DataHoraReserva = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DataHoraRejeicao = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DataHoraCancelamento = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DataEntrega = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DanosHabitacaoEntrega = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ObservacoesEntrega = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DataRececao = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DanosHabitacaoRececao = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ObservacoesRececao = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ManifestacaoInteresseId = table.Column<int>(type: "int", nullable: true),
                    HabitacaoId = table.Column<int>(type: "int", nullable: true),
                    ClienteId = table.Column<int>(type: "int", nullable: true),
                    FuncionarioReservaId = table.Column<int>(type: "int", nullable: false),
                    FuncionarioEntregaId = table.Column<int>(type: "int", nullable: false),
                    FuncionarioRececaoId = table.Column<int>(type: "int", nullable: false),
                    FuncionarioId = table.Column<int>(type: "int", nullable: true),
                    FuncionarioId1 = table.Column<int>(type: "int", nullable: true),
                    FuncionarioId2 = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Arrendamentos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Arrendamentos_Clientes_ClienteId",
                        column: x => x.ClienteId,
                        principalTable: "Clientes",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Arrendamentos_Funcionarios_FuncionarioEntregaId",
                        column: x => x.FuncionarioEntregaId,
                        principalTable: "Funcionarios",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Arrendamentos_Funcionarios_FuncionarioId",
                        column: x => x.FuncionarioId,
                        principalTable: "Funcionarios",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Arrendamentos_Funcionarios_FuncionarioId1",
                        column: x => x.FuncionarioId1,
                        principalTable: "Funcionarios",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Arrendamentos_Funcionarios_FuncionarioId2",
                        column: x => x.FuncionarioId2,
                        principalTable: "Funcionarios",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Arrendamentos_Funcionarios_FuncionarioRececaoId",
                        column: x => x.FuncionarioRececaoId,
                        principalTable: "Funcionarios",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Arrendamentos_Funcionarios_FuncionarioReservaId",
                        column: x => x.FuncionarioReservaId,
                        principalTable: "Funcionarios",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Arrendamentos_Habitacoes_HabitacaoId",
                        column: x => x.HabitacaoId,
                        principalTable: "Habitacoes",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Arrendamentos_ManifestacoesInteresse_ManifestacaoInteresseId",
                        column: x => x.ManifestacaoInteresseId,
                        principalTable: "ManifestacoesInteresse",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "ArrendamentosHabitacoesEquipamentosOpcionais",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Descricao = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Preco = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    ArrendamentoId = table.Column<int>(type: "int", nullable: false),
                    HabitacaoEquipamentoOpcionalId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ArrendamentosHabitacoesEquipamentosOpcionais", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ArrendamentosHabitacoesEquipamentosOpcionais_Arrendamentos_ArrendamentoId",
                        column: x => x.ArrendamentoId,
                        principalTable: "Arrendamentos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ArrendamentosHabitacoesEquipamentosOpcionais_HabitacoesEquipamentos_HabitacaoEquipamentoOpcionalId",
                        column: x => x.HabitacaoEquipamentoOpcionalId,
                        principalTable: "HabitacoesEquipamentos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ArrendamentosHabitacoesServicosOpcionais",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Descricao = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Preco = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    ArrendamentoId = table.Column<int>(type: "int", nullable: false),
                    HabitacaoServicoOpcionalId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ArrendamentosHabitacoesServicosOpcionais", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ArrendamentosHabitacoesServicosOpcionais_Arrendamentos_ArrendamentoId",
                        column: x => x.ArrendamentoId,
                        principalTable: "Arrendamentos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ArrendamentosHabitacoesServicosOpcionais_HabitacoesServicos_HabitacaoServicoOpcionalId",
                        column: x => x.HabitacaoServicoOpcionalId,
                        principalTable: "HabitacoesServicos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "FotosDanosHabitacoes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Foto = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Descricao = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ArrendamentoId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FotosDanosHabitacoes", x => x.Id);
                    table.ForeignKey(
                        name: "FK_FotosDanosHabitacoes_Arrendamentos_ArrendamentoId",
                        column: x => x.ArrendamentoId,
                        principalTable: "Arrendamentos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Arrendamentos_ClienteId",
                table: "Arrendamentos",
                column: "ClienteId");

            migrationBuilder.CreateIndex(
                name: "IX_Arrendamentos_FuncionarioEntregaId",
                table: "Arrendamentos",
                column: "FuncionarioEntregaId");

            migrationBuilder.CreateIndex(
                name: "IX_Arrendamentos_FuncionarioId",
                table: "Arrendamentos",
                column: "FuncionarioId");

            migrationBuilder.CreateIndex(
                name: "IX_Arrendamentos_FuncionarioId1",
                table: "Arrendamentos",
                column: "FuncionarioId1");

            migrationBuilder.CreateIndex(
                name: "IX_Arrendamentos_FuncionarioId2",
                table: "Arrendamentos",
                column: "FuncionarioId2");

            migrationBuilder.CreateIndex(
                name: "IX_Arrendamentos_FuncionarioRececaoId",
                table: "Arrendamentos",
                column: "FuncionarioRececaoId");

            migrationBuilder.CreateIndex(
                name: "IX_Arrendamentos_FuncionarioReservaId",
                table: "Arrendamentos",
                column: "FuncionarioReservaId");

            migrationBuilder.CreateIndex(
                name: "IX_Arrendamentos_HabitacaoId",
                table: "Arrendamentos",
                column: "HabitacaoId");

            migrationBuilder.CreateIndex(
                name: "IX_Arrendamentos_ManifestacaoInteresseId",
                table: "Arrendamentos",
                column: "ManifestacaoInteresseId");

            migrationBuilder.CreateIndex(
                name: "IX_ArrendamentosHabitacoesEquipamentosOpcionais_ArrendamentoId",
                table: "ArrendamentosHabitacoesEquipamentosOpcionais",
                column: "ArrendamentoId");

            migrationBuilder.CreateIndex(
                name: "IX_ArrendamentosHabitacoesEquipamentosOpcionais_HabitacaoEquipamentoOpcionalId",
                table: "ArrendamentosHabitacoesEquipamentosOpcionais",
                column: "HabitacaoEquipamentoOpcionalId");

            migrationBuilder.CreateIndex(
                name: "IX_ArrendamentosHabitacoesServicosOpcionais_ArrendamentoId",
                table: "ArrendamentosHabitacoesServicosOpcionais",
                column: "ArrendamentoId");

            migrationBuilder.CreateIndex(
                name: "IX_ArrendamentosHabitacoesServicosOpcionais_HabitacaoServicoOpcionalId",
                table: "ArrendamentosHabitacoesServicosOpcionais",
                column: "HabitacaoServicoOpcionalId");

            migrationBuilder.CreateIndex(
                name: "IX_FotosDanosHabitacoes_ArrendamentoId",
                table: "FotosDanosHabitacoes",
                column: "ArrendamentoId");

            migrationBuilder.CreateIndex(
                name: "IX_ManifestacoesInteresse_ClienteId",
                table: "ManifestacoesInteresse",
                column: "ClienteId");

            migrationBuilder.CreateIndex(
                name: "IX_ManifestacoesInteresse_HabitacaoId",
                table: "ManifestacoesInteresse",
                column: "HabitacaoId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ArrendamentosHabitacoesEquipamentosOpcionais");

            migrationBuilder.DropTable(
                name: "ArrendamentosHabitacoesServicosOpcionais");

            migrationBuilder.DropTable(
                name: "FotosDanosHabitacoes");

            migrationBuilder.DropTable(
                name: "Arrendamentos");

            migrationBuilder.DropTable(
                name: "ManifestacoesInteresse");

            migrationBuilder.AlterColumn<string>(
                name: "Descricao",
                table: "TiposHabitacoes",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Descricao",
                table: "Servicos",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<DateTime>(
                name: "InicioAtividade",
                table: "Locadores",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified),
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Foto",
                table: "Locadores",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Morada",
                table: "Gestores",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Localidade",
                table: "Gestores",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Foto",
                table: "Gestores",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CodigoPostal",
                table: "Gestores",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Morada",
                table: "Funcionarios",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Localidade",
                table: "Funcionarios",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Foto",
                table: "Funcionarios",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CodigoPostal",
                table: "Funcionarios",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Descricao",
                table: "Equipamentos",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Foto",
                table: "Clientes",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);
        }
    }
}

﻿using HabitAqui.Models.Arrendamentos;
using HabitAqui.Models.Habitacoes;
using HabitAqui.Models.Utilizadores;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace HabitAqui.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        // Utilizadores
        public DbSet<Administrador> Administradores { get; set; }
        public DbSet<Gestor> Gestores { get; set; }
        public DbSet<Funcionario> Funcionarios { get; set; }
        public DbSet<Proprietario> Proprietarios { get; set; }
        public DbSet<Arrendatario> Arrendatarios { get; set; }

        // Habitacoes
        public DbSet<Habitacao> Habitacoes { get; set; }
        public DbSet<TipoHabitacao> TiposHabitacoes { get; set; }
        public DbSet<Equipamento> Equipamentos { get; set; }
        public DbSet<HabitacaoEquipamento> HabitacoesEquipamentos { get; set; }
        public DbSet<Servico> Servicos { get; set; }
        public DbSet<HabitacaoServico> HabitacoesServicos { get; set; }
        public DbSet<Avaliacao> Avaliacoes { get; set; }

        // Arrendamentos
        public DbSet<Mediador> Mediadores { get; set; }
        public DbSet<PreReserva> PreReservas { get; set; }
        public DbSet<Arrendamento> Arrendamentos { get; set; }
        public DbSet<ArrendamentoHabitacaoEquipamentoOpcional> 
            ArrendamentosHabitacoesEquipamentosOpcionais { get; set; }
        public DbSet<ArrendamentoHabitacaoServicoOpcional> 
            ArrendamentosHabitacoesServicosOpcionais { get; set; }
        
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
            Administradores = Set<Administrador>();
            Gestores = Set<Gestor>();
            Funcionarios = Set<Funcionario>();
            Proprietarios = Set<Proprietario>();
            Arrendatarios = Set<Arrendatario>();

            Habitacoes = Set<Habitacao>();
            TiposHabitacoes = Set<TipoHabitacao>();
            Equipamentos = Set<Equipamento>();
            HabitacoesEquipamentos = Set<HabitacaoEquipamento>();
            Servicos = Set<Servico>();
            HabitacoesServicos = Set<HabitacaoServico>();
            Avaliacoes = Set<Avaliacao>();

            Mediadores = Set<Mediador>();
            PreReservas = Set<PreReserva>();
            Arrendamentos = Set<Arrendamento>();
            ArrendamentosHabitacoesEquipamentosOpcionais = Set<ArrendamentoHabitacaoEquipamentoOpcional>();
            ArrendamentosHabitacoesServicosOpcionais = Set<ArrendamentoHabitacaoServicoOpcional>();
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Método base
            base.OnModelCreating(modelBuilder);

            // Comportamentos específicos
            modelBuilder.Entity<Habitacao>()
                .HasOne(h => h.Proprietario)
                .WithMany(p => p.Habitacoes)
                .HasForeignKey(h => h.ProprietarioId)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
﻿using System.ComponentModel.DataAnnotations;

namespace HabitAqui.ViewModels
{
    public class ArrendamentoViewModel
    {
        [Display(Name = "Nome da Habitação", Prompt = "Introduza o nome da habitação")]
        [StringLength(500)]
        public string NomeHabitacao { get; set; } = string.Empty;

        [Display(Name = "Tipo de Habitação", Prompt = "Introduza o nome do tipo de habitação")]
        [Required(ErrorMessage = "Introduza o nome do tipo de habitação")]
        [StringLength(500)]
        public string NomeTipo { get; set; } = string.Empty;

        [Display(Name = "Localidade", Prompt = "Introduza a localidade da habitação")]
        [StringLength(200)]
        public string Localidade { get; set; } = string.Empty;

        [Display(Name = "País", Prompt = "Introduza o país da habitação")]
        [StringLength(50)]
        public string Pais { get; set; } = string.Empty;

        [Display(Name = "Renda Mensal", Prompt = "Introduza a renda mensal da habitação")]
        [DisplayFormat(DataFormatString = "{0:C, FR-fr}")]
        [Range(0, int.MaxValue, ErrorMessage = "Mínimo: 0")]
        public decimal RendaMensal { get; set; }

        [Display(Name = "Data de Início", Prompt = "Introduza a data de início do arrendamento: yyyy-mm-dd")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
        public DateTime? DataInicio { get; set; }

        [Display(Name = "Data de Fim", Prompt = "Introduza a data do fim do arrendamento: yyyy-mm-dd")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
        public DateTime? DataFim { get; set; }

        [Display(Name = "Nome do Proprietario", Prompt = "Introduza o nome do proprietário")]
        [StringLength(200)]
        public string NomeProprietario { get; set; } = string.Empty;

        [Display(Name = "Nome do Mediador", Prompt = "Introduza o nome do mediador")]
        [StringLength(200)]
        public string NomeMediador { get; set; } = string.Empty;

        [Display(Name = "Avaliação Média", Prompt = "Introduza a avaliação média (0 a 5)")]
        [Range(0, 5, ErrorMessage = "Mínimo: 0; Máximo: 5")]
        public int? AvaliacaoMedia { get; set; }
    }
}

﻿using HabitAqui.Models.Habitacoes;
using System.ComponentModel.DataAnnotations;

namespace HabitAqui.ViewModels
{
    public class PesquisaHabitacaoViewModel
    {
        public List<Habitacao>? ListaHabitacoes { get; set; }

        public int NumResultados { get; set; }

        [Display(Name = "Pesquisa de habitações", Prompt = "Introduza o texto a pesquisar")]
        public string? TextoAPesquisar { get; set; }

        [Display(Name = "Data de Início", Prompt = "Introduza a data de início do arrendamento: yyyy-mm-dd")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
        public DateTime? DataInicio { get; set; }

        [Display(Name = "Data de Fim", Prompt = "Introduza a data do fim do arrendamento: yyyy-mm-dd")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
        public DateTime? DataFim { get; set; }

        [Display(Name = "Número Mínimo de Meses de Arrendamento",
            Prompt = "Introduza o número mínimo de meses válidos para arrendamento")]
        [Range(1, int.MaxValue, ErrorMessage = "Mínimo: 1")]
        public int? NumMinMesesArrendamento { get; set; }
    }
}
